<?php 

	//DAYS
	
	define('SATURDAY_DAY','শনিবার');
	define('SUNDAY_DAY','রবিবার');
	define('MONDAY_DAY','সোমবার');
	define('TUESDAY_DAY','মঙ্গলবার');
	define('WEDNESSDAY_DAY','বুধবার');
	define('THRUSDAY_DAY','বৃহস্পতিবার');
	define('FRIDAY_DAY','শুক্রবার');
	//MENU------
	define('DASHBOARD_MENU','ড্যাশবোর্ড');
	define('STUDENT_MENU','শিক্ষার্থী');
	define('ADD_STUDENT_MENU','শিক্ষার্থী সংযোজন করুন');
	define('STUDENT_INFORMATION_MENU','শিক্ষার্থীদের তথ্যাবলী');
	define('STAFF_MENU','শিক্ষক/কর্মচারী');
	define('ADD_STAFF_MENU','শিক্ষক/কর্মচারী সংযোজন করুন');
	define('STAFF_INFORMATION_MENU','শিক্ষক/কর্মচারীগণের তথ্যাবলী');
	define('GUARDIAN_MENU','অভিভাবক');
	define('ADD_GUARDIAN_MENU','অভিভাবক সংযোজন করুন');
	define('GUARDIAN_INFORMATION_MENU','অভিভাবকগণের তথ্যাবলী');
	define('CLASS_MENU','শ্রেণী');
	define('ADD_CLASS_MENU','শ্রেণী সংযোজন করুন');
	define('CLASS_INFORMATION_MENU','শ্রেণীর তথ্যাবলী');
	define('ADD_SECTION_MENU','বিভাগ সংযোজন করুন');
	define('STUDENT_FEES_MENU','শিক্ষার্থীদের ফি সমূহ');
	define('CREATE_STUDENT_PAYMENT_MENU','শিক্ষার্থীর ফি তৈরি করুন');
	define('CREATE_BULK_STUDENT_PAYMENT_MENU','একাধিক ছাত্র/ছাত্রীর ফি/বেতন পরিশোধ মেনু সংযোজন করুন');
	define('STUDENT_PAYMENT_MENU','ফি/বেতন পরিশোধ করুন');
	define('PAYMENT_HISTORY_BY_STUDENT_MENU','ছাত্র/ছাত্রীদের বেতন পরিশোধের নথি');
	define('STUDENT_PAYMENT_REPORT_MENU','ছাত্র/ছাত্রীদের বেতন পরিশোধের বিবরণ');
	define('SUBJECT_MENU','পাঠ্য বিষয়');
	define('CLASS_ROUTINE_MENU','শ্রেণী সময়সূচি');
	define('ADD_ROUTINE_MENU',' শ্রেণী সময়সূচি সংযুক্ত করুন');
	define('VIEW_ROUTINE_MENU','শ্রেণী সময়সূচি দেখুন');
	define('ATTENDANCE_MENU','উপস্থিতি');
	define('TODAY_STAFF_ATTENDANCE_MENU','আজকের কর্মকর্তা/কর্মচারীগণের উপস্থিতি');
	define('TODAY_STUDENT_ATTENDANCE_MENU','আজকের ছাত্র/ছাত্রী উপস্থিতি');
	define('MONTHLY_STUDENT_ATTENDANCE_MENU','ছাত্র/ছাত্রী উপস্থিতি প্রতিবেদন(মাসিক)');
	define('MONTHLY_STAFF_ATTENDANCE_MENU','কর্মকর্তা/কর্মচারীগণের উপস্থিতি(মাসিক)');
	define('STUDENT_ATTENDANCE_MENU','ছাত্র/ছাত্রীদের উপস্থিতি পর্যবেক্ষণ');
	define('EXAM_MENU','পরীক্ষা');
	define('Add_EXAM_MENU','পরীক্ষা সংযুক্ত করুন');
	define('EXAM_LIST_MENU','পরীক্ষার তালিকা');
	define('EXAM_GRADE_MENU','পরীক্ষার শ্রেণী/ক্রম নির্ধারণ');
	define('MANAGE_EXAM_MARK_MENU','প্রাপ্ত নম্বর নির্ধারণ');
	define('TABULATION_SHEET_MENU','টেবুলেশন শিট');
	define('PAYROLL_MENU','বেতনের তালিকা');
	define('CREATE_STAFF_PAYMENT_MENU','অর্থ প্রদান করুন');
	define('CREATE_STAFF_BULK_PAYMENT_MENU','একাধিক অর্থ প্রদান করুন');
	define('STAFF_PAYMENT_MENU','কর্মকর্তা/কর্মচারীগণের বেতন পরিশোধ করুন');
	define('STAFF_PAYMENT_REPORT_MENU','বেতন পরিশোধের বিবরণ');
	define('ACCOUNTING_MENU','হিসাবরক্ষণ');
	define('INCOME_MENU','আয়');
	define('EXPENSE_MENU','ব্যয়');
	define('LIBRARY_MENU','গ্রন্থাগার');
	define('MANAGE_BOOKS_MENU','বই বিতরণ');
	define('BOOK_LIST_MENU','বইয়ের তালিকা');
	define('DORMITORY_MENU','ছাত্রাবাস');
	define('MANAGE_DORMITORY_MENU','ছাত্রাবাস পরিচালনা করুন');
	define('NOTICE_MENU','বিজ্ঞপ্তি ফলক');
	define('MANAGE_NOTICE_MENU','বিজ্ঞপ্তি পরিচালনা করুন');
	define('SETTING_MENU','পদ্ধতি স্থাপন');
	define('GENERAL_SETTING_MENU','প্রতিষ্ঠান সংযোজন');
	define('USER_SETTING_MENU','ব্যবহারকারী সংযোজন');
	define('MESSEGE_SETTING_MENU','বার্তা সংযোজন');
	define('LANGUAGE_SETTING_MENU','ভাষা সংযোজন');
	
	
	//ACTION
	
	define('TABLE_ACTION','কার্যকলাপ');
	define('MARKSHEET_ACTION','নম্বার পত্র');
	define('PROFILE_ACTION','পরিলেখ');
	define('EDIT_ACTION','সম্পাদনা করুন');
	define('DELETE_ACTION','মুছে ফেলুন');
	
	
	//Massege
	
	
	define('ENTRY_SUCCESS_MSG','সফল ভাবে সংযুক্ত হয়েছে!');
	define('ENTRY_DELETE_MSG','সফল ভাবে মুছে ফেলা হয়েছে!');
	define('ENTRY_UPDATE_MSG','সফল ভাবে হালনাগাদ করা হয়েছে!');
	define('ENTRY_FAILED_MSG','সংযুক্ত করতে ব্যর্থ হয়েছেন!');
	define('ENTRY_DUPLICATE_MSG','সদৃশ তথ্য বিদ্যমান!');
	define('SUCCESS_MSG','সফল ভাবে সম্পন্ন হয়েছে!');
	//PAGE TITLE
	
	
	define('DASHBOARD_TITLE','ড্যাশবোর্ডে আপনাকে স্বাগতম');
	define('ADD_STUDENT_TITLE','ছাত্র/ছাত্রী সংযুক্ত করুন');
	define('STUDENT_INFORMATION_TITLE','ছাত্র/ছাত্রীদের তথ্যাবলী');
	define('STUDENT_MARKSHEET_TITLE','ছাত্র/ছাত্রীদের নম্বরপত্র');
	define('STUDENT_PROFILE_TITLE','ছাত্র/ছাত্রীদের পরিলেখ');
	define('STUDENT_EDIT_TITLE','ছাত্র/ছাত্রীদের তথ্যাবলী হালনাগাদ করুন');
	define('ADD_STAFF_TITLE','কর্মকর্তা/কর্মচারীগণের শিরোনাম সংযুক্ত করুন');
	define('STAFF_INFORMATION_TITLE','কর্মকর্তা/কর্মচারিগণের তথ্যাবলী');
	define('STAFF_PROFILE_TITLE','কর্মকর্তা/কর্মচারিগণের পরিলেখ');
	define('STAFF_EDIT_TITLE','কর্মকর্তা/কর্মচারিগণের তথ্যাবলী হালনাগাদ করুন');
	define('ADD_GUARDIAN_TITLE','অভিভাবক সংযুক্ত করুন');
	define('GUARDIAN_INFORMATION_TITLE','অভিভাবকের তথ্যাবলী');
	define('GUARDIAN_PROFILE_TITLE','অভিভাবকের পরিলেখ');
	define('GUARDIAN_EDIT_TITLE','অভিভাবকের তথ্যাবলী হালনাগাদ করুন');
	define('ADD_CLASS_TITLE','শ্রেণী সংযুক্ত করুন');
	define('CLASS_INFORMATION_TITLE','শ্রেণীর তথ্যাবলী');
	define('CLASS_EDIT_TITLE','শ্রেণীর তথ্যাবলী হালনাগাদ করুন');
	define('ADD_SECTION_TITLE',' শাখা সংযুক্ত করুন');
	define('CREATE_STUDENT_PAYMENT_TITLE','ছাত্র/ছাত্রীদের পরিশোধ তৈরি করুন');
	define('CREATE_BULK_STUDENT_PAYMENT_TITLE','ছাত্র/ ছাত্রীদের পরিশোধ তৈরি করুন (শ্রেণী ভিত্তিক)');
	define('STUDENT_PAYMENT_TITLE','ছাত্র/ছাত্রীদের ফি পরিশোধ');
	define('PAYMENT_HISTORY_BY_STUDENT_TITLE','ছাত্র/ছাত্রীদের ফি পরিশোধের নথি');
	define('STUDENT_PAYMENT_REPORT_TITLE','পরিশোধের বিবরণ');
	define('ADD_SUBJECT_TITLE','বিষয় সংযুক্ত করুন');
	define('MANAGE_SUBJECT_TITLE','বিষয় পরিচালনা');
	define('ADD_ROUTINE_TITLE','শ্রেণীর সময়সূচি বিন্যাস করুন');
	define('VIEW_ROUTINE_TITLE','শ্রেণীর সময়সূচি দেখুন');
	define('TODAY_STAFF_ATTENDANCE_TITLE','আজকের কর্মকর্তা/কর্মচারী উপস্থিতি');
	define('TODAY_STUDENT_ATTENDANCE_TITLE','আজকের ছাত্র/ছাত্রী উপস্থিতি');
	define('MONTHLY_STUDENT_ATTENDANCE_TITLE',' মাসিক ছাত্র/ছাত্রী উপস্থিতি পর্যালোচনা');
	define('MONTHLY_STAFF_ATTENDANCE_TITLE','মাসিক কর্মকর্তা/কর্মচারী উপস্থিতি পর্যালোচনা');
	define('STUDENT_ATTENDANCE_TITLE','দৈনিক ছাত্র/ছাত্রী উপস্থিতি দেখুন');
	define('ADD_EXAM_TITLE','পরীক্ষার নাম সংযুক্ত করুন');
	define('CREATE_EXAM_TITLE','পরীক্ষা সংযোজন করুন ');
	define('EXAM_LIST_TITLE','সকল পরীক্ষার তালিকা');
	define('EXAM_GRADE_TITLE','পরীক্ষার শ্রেণী সমন্বয় করুন');
	define('EXAM_GRADE_ADD_TITLE','পরীক্ষার শ্রেণী সংযুক্ত করুন');
	define('EXAM_GRADE_EDIT_TITLE','পরীক্ষার শ্রেণী সম্পাদনা করুন');
	define('MANAGE_EXAM_MARK_TITLE','পরীক্ষায় প্রাপ্ত নম্বর সমন্বয় করুন');
	define('TABULATION_SHEET_TITLE','পরীক্ষার ফলাফল ছক আকারে লিখিত পত্র');
	define('CREATE_STAFF_PAYMENT_TITLE','কর্মকর্তা/কর্মচারীদের পরিশোধ সংযুক্ত করুন');
	define('CREATE_STAFF_BULK_PAYMENT_TITLE','একাধিক পরিশোধ সংযুক্ত করুন');
	define('STAFF_PAYMENT_TITLE','কর্মকর্তা/কর্মচারীদের পরিশোধ');
	define('STAFF_PAYMENT_REPORT_TITLE','কর্মকর্তা/কর্মচারীদের পরিশোধ এর পর্যালোচনা');
	define('ACCOUNTING_TITLE','হিসাবরক্ষণ');
	define('INCOME_TITLE','আয়');
	define('EXPENSE_TITLE','ব্যায়');
	define('LIBRARY_TITLE','গ্রন্থাগার');
	define('MANAGE_BOOKS_TITLE','বই বিতরণ');
	define('BOOK_LIST_TITLE','বইয়ের তালিকা');
	define('BOOK_EDIT_TITLE','বইয়ের তথ্যাবলী হালনাগাদ করুন');
	define('MANAGE_DORMITORY_TITLE','ছাত্রাবাস ব্যাবস্থাপনা');
	define('NOTICE_TITLE','বিজ্ঞপ্তি ফলক');
	define('MANAGE_NOTICE_TITLE','বিজ্ঞপ্তি ব্যাবস্থাপনা');
	define('SETTING_TITLE','পদ্ধতি সংযোজন');
	define('GENERAL_SETTING_TITLE','প্রতিষ্ঠান সংযোজন');
	define('USER_SETTING_TITLE','ব্যবহারকারী সংযোজন');
	define('MESSEGE_SETTING_TITLE','বার্তা সংযোজন');
	define('LANGUAGE_SETTING_TITLE','ভাষা সংযোজন');
	
	//FORM-> ADD STUDENT
	
	define('INSERT_NEW_PARENT_FORM','অভিভাবক সংযোজন করুন');
	define('EXIST_PARENT_FORM','অভিভাবকদের মধ্যে থেকে সংযোজন করুন');
	define('CLASS_NAME_FORM','শ্রেণীর নাম');
	define('SECTION_NAME_FORM','শাখার নাম');
	define('GUARDIAN_NAME_FORM','অভিভাবকের নাম');
	define('ROLL_NUMBER_FORM','ক্রমিক নম্বর');
	define('NAME_ENGLISH_FORM','নাম (ইংরেজিতে)');
	define('NAME_BANGLA_FORM','নাম (বাংলায়)');
	define('FATHER_NAME_FORM','পিতার নাম');
	define('MOTHER_NAME_FORM','মাতার নাম');
	define('BIRTHDAY_FORM','জন্মদিন');
	define('GENDER_FORM','লিঙ্গ');
	define('BLOOD_FORM','রক্তের গ্রূপ');
	define('PHONE_FORM','ফোন নম্বর');
	define('PRESENT_ADDRESS_FORM','বর্তমান ঠিকানা');
	define('PARMANENT_ADDRESS_FORM','স্থায়ী ঠিকানা');
	define('EMAIL_FORM','ইমেইল');
	define('NATIONAL_ID_FORM','জাতীয় পরিচয়পত্র নম্বর');
	define('BIRTH_REGISTRATION_FORM','জন্ম নিবন্ধন নম্বর');
	define('RELIGION_FORM','ধর্ম');
	define('RESPONSIBLE_TEACHER_FORM','দায়িত্বশীল শিক্ষক');
	define('USERNAME_FORM','ব্যবহারকারীর নাম');
	define('PASSWORD_FORM','পাসওয়ার্ড');
	define('ADDMISSION_DATE_FORM','ভর্তির তারিখ');
	define('DORMITORY_FORM','ছাত্রাবাস');
	define('TRANSPORT_FORM','পরিবহন রুট');
	define('PHOTO_FORM','ছবি');
	define('MALE_FORM','পুরুষ');
	define('FEMALE_FORM','মহিলা');
	define('SELECT_TEACHER_FORM','শিক্ষক নির্বাচন করুন');
	define('SELECT_GUARDIAN_FORM','অভিভাবক নির্বাচন করুন');
	define('SELECT_CLASS_FORM','শ্রেণী নির্বাচন করুন');
	define('SELECT_SECTION_FORM','শাখা নির্বাচন করুন');
	
	///TABLE---
	
	
	//FORM-> ADD STAFF_INFORMATION_MENU
	
	define('STAFF_NAME_FORM','কর্মকর্তা/কর্মচারীর নাম');
	define('QUALIFICATION_FORM','শিক্ষাগত যোগ্যতা');
	define('DESIGNATION_FORM','পদবি');
	define('DEPARTMENT_FORM','কর্মকর্তা/কর্মচারীর বিভাগ');
	define('SALARY_FORM','বেতন');
	define('JOINING_DATE_FORM','যোগদানের তারিখ');
	
	//FORM -> ADD GUARDIAN
	
	
	define('REALATION_FORM','সম্পর্ক');
	define('PROFESSION_FORM','পেশা');
	
	//FORM -> ADD CLASS
	define('TEACHER_FORM','শিক্ষকের নাম');
	define('NUMERICAL_ID_FORM','সংখ্যাসূচক চিহ্ন');
	
	//FORM-> CREATE STUDENT_PAYMENT_MENU
	
	define('STUDENT_NAME_FORM','ছাত্রের নাম');
	define('PAYMENT_NAME_FORM','পরিশোধকারীর নাম');
	define('MONTH_FORM','পরিশোধের মাস');
	define('PAID_AMOUNT_FORM','প্রদানকৃত টাকার পরিমান');
	define('RECEAVEABLE_AMOUNT_FORM','গ্রহণযোগ্য টাকার পরিমাণ');
	define('CREATE_PAYMENT_FORM','পরিশোধ সম্পন্ন করুন');
	define('COMMENT_FORM','মন্তব্য');
	define('TOTAL_AMOUNT_FORM','মোট টাকার পরিমান');
	define('PAID_DATE_FORM','পরিশোধের তারিখ');
	define('TO_DATE_FORM','প্রতি');
	define('FROM_DATE_FORM','থেকে');
	define('FIND_FORM','খুঁজে দেখুন');
	
	//FORM-> SUBJECT_MENU
	define('SUBJECT_NAME_FORM','বিষয়ের নাম');
	
	//FORM-> ROUTINE
	
	define('RESET_ROUTINE_FORM','কার্য সূচি পুনরায় সম্পাদন করুন');
	define('ADD_ROUTINE_FORM','কার্য সূচি সম্পাদন করুন');
	
	//FORM-> ATTENDANCE_MENU
	define('SELECT_DEPARTMENT_FORM','বিভাগ নির্বাচন করুন');
	define('ATTEND_NOW_FORM','যোগদান করুন');
	define('PRESENT_FORM','উপস্থিত');
	define('ABSENT_FORM','অনুপস্থিত');
	define('SET_ATTENDANCE_FORM','উপস্থিতি সম্পাদন করুন');
	
	//FORM-> EXAM_GRADE_MENU
	define('EXAM_NAME_FORM','পরীক্ষার নাম');
	define('EXAM_DURATION_FORM','পরীক্ষার সময়কাল');
	define('EXAM_PASS_MARK_FORM','কৃতকার্য হওয়ার মান');
	define('EXAM_FULL_MARK_FORM','পূর্ণমান');
	define('CREATE_EXAM_FORM','মান সম্পাদন করুন');
	define('ADD_EXAM_FORM','পরীক্ষা সংযুক্ত করুন');
	
	define('GRADE_NAME_FORM','গ্রেড/শ্রেণীর নাম');
	define('GRADE_MARK_UPTO_FORM','মান (পর্যন্ত)');
	define('GRADE_MARK_FROM_FORM','মান (থেকে)');
	define('GRADE_POINT_FORM','গ্রেড পয়েন্ট');
	define('ADD_GRADE_FORM','গ্রেড সংযুক্ত করুন');
	
	define('SUBMIT_MARK_FORM','মার্ক/মান দাখিল করুন');
	
	//FORM-> PAYROLL
	
	define('DUE_AMOUNT_FORM','বাকি টাকার পরিমান');
	
	//FORM->ACCOUNTING_MENU
	define('ADD_INCOME_FORM','আয় সংযোজন করুন');
	define('ADD_INCOME_CATEGORY_FORM','আয়ের শ্রেণী সংযোজন করুন');
	define('INCOME_CATEGORY_FORM','আয়ের শ্রেণী');
	define('INVOICE_NUMBER_FORM','চালান নম্বর');
	define('DESCRIPTION_FORM','বর্ণনা');
	
	//FORM-> LIBRARY
	
	define('BOOK_ID_FORM','বই নং');
	define('BOOK_NAME_FORM','বইয়ের নাম');
	define('GIVING_DATE_FORM','প্রদান করার তারিখ');
	define('RETURNING_DATE_FORM','ফেরত নেওয়ার তারিখ');
	define('RETURN_FORM','ফেরত');
	
	
	define('BOOK_AUTHOR_FORM','লেখক');
	define('BOOK_PRICE_FORM','মূল্য');
	define('ADD_BOOK_FORM','বই সংযুক্ত করুন');
	
	//FORM-> NOTICE_MENU
	define('NOTICE_TITLE_FORM','নোটিশের শিরোনাম');
	define('NOTICE_DESCRIPTION_FORM','নোটিশের বর্ণনা');
	
	//FORM-> SETTING
	define('INSTITUTION_NAME_FORM','প্রতিষ্ঠানের নাম');
	define('INSTITUTION_MOTO_FORM','প্রতিষ্ঠানের লক্ষ্য ও উদ্দেশ্যে');
	define('ESTABLISHMENT_DATE_FORM','প্রতিষ্ঠার তারিখ');
	define('BOARD_FORM','শিক্ষা বোর্ড');
	define('DISTRICT_FORM','জেলা');
	define('CITY_FORM','শহর');
	define('INSTITUTION_CODE_FORM','প্রতিষ্ঠানের কোড নং');
	define('ACADEMIC_YEAR_FORM','শিক্ষাবর্ষ');
	
?>