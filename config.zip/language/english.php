<?php 

	//DAYS
	
	define('SATURDAY_DAY','Saturday');
	define('SUNDAY_DAY','Sunday');
	define('MONDAY_DAY','Monday');
	define('TUESDAY_DAY','Tuesday');
	define('WEDNESSDAY_DAY','Wednesday');
	define('THRUSDAY_DAY','Thrusday');
	define('FRIDAY_DAY','Friday');
	//MENU------
	define('DASHBOARD_MENU','Dashboard');
	define('STUDENT_MENU','Students');
	define('ADD_STUDENT_MENU','Add Student');
	define('STUDENT_INFORMATION_MENU','Student Information');
	define('STAFF_MENU','Staff');
	define('ADD_STAFF_MENU','Add Staff');
	define('STAFF_INFORMATION_MENU','Staff Information');
	define('GUARDIAN_MENU','Guardian');
	define('ADD_GUARDIAN_MENU','Add Guardian');
	define('GUARDIAN_INFORMATION_MENU','Guardian Information');
	define('CLASS_MENU','Class');
	define('ADD_CLASS_MENU','Add Class');
	define('CLASS_INFORMATION_MENU','Class Information');
	define('ADD_SECTION_MENU','Add Section');
	define('STUDENT_FEES_MENU','Student Fee');
	define('CREATE_STUDENT_PAYMENT_MENU','Create Student Payment');
	define('CREATE_BULK_STUDENT_PAYMENT_MENU','Create Bulk Student Payment');
	define('STUDENT_PAYMENT_MENU','Fee Payment');
	define('PAYMENT_HISTORY_BY_STUDENT_MENU','Student Payment History');
	define('STUDENT_PAYMENT_REPORT_MENU','Student Payment Report');
	define('SUBJECT_MENU','Subject');
	define('CLASS_ROUTINE_MENU','Class Routine');
	define('ADD_ROUTINE_MENU',' Add Routine');
	define('VIEW_ROUTINE_MENU','View Routine');
	define('ATTENDANCE_MENU','Attendance');
	define('TODAY_STAFF_ATTENDANCE_MENU','Today Staff Attendance');
	define('TODAY_STUDENT_ATTENDANCE_MENU','Today Student Attendance');
	define('MONTHLY_STUDENT_ATTENDANCE_MENU','Student Attendance Report(Monthly)');
	define('MONTHLY_STAFF_ATTENDANCE_MENU','Staff Attendance Report(Monthly)');
	define('STUDENT_ATTENDANCE_MENU','Student Attendance Overview');
	define('EXAM_MENU','Examination');
	define('Add_EXAM_MENU','Add Exam');
	define('EXAM_LIST_MENU','Examination List');
	define('EXAM_GRADE_MENU','Manage Grade');
	define('MANAGE_EXAM_MARK_MENU','Manage Marks');
	define('TABULATION_SHEET_MENU','Tabulation Sheet');
	define('PAYROLL_MENU','Payroll');
	define('CREATE_STAFF_PAYMENT_MENU','Create Payment');
	define('CREATE_STAFF_BULK_PAYMENT_MENU','Create Bulk Payment');
	define('STAFF_PAYMENT_MENU','Paying Staff');
	define('STAFF_PAYMENT_REPORT_MENU','Payment Report');
	define('ACCOUNTING_MENU','Accounting');
	define('INCOME_MENU','Income');
	define('EXPENSE_MENU','Expences');
	define('LIBRARY_MENU','Library');
	define('MANAGE_BOOKS_MENU','Book Distribution');
	define('BOOK_LIST_MENU','Book List');
	define('DORMITORY_MENU','Dormitory');
	define('MANAGE_DORMITORY_MENU','Manage Dormitory');
	define('NOTICE_MENU','Notice Board');
	define('MANAGE_NOTICE_MENU','Manage Notice');
	define('SETTING_MENU','System Setting');
	define('GENERAL_SETTING_MENU','Institution Setting');
	define('USER_SETTING_MENU','User Setting');
	define('MESSEGE_SETTING_MENU','Messeging Setting');
	define('LANGUAGE_SETTING_MENU','Language Setting');
	
	
	//ACTION
	
	define('SERIAL_TABLE','SN');
	define('TABLE_ACTION','Action');
	define('MARKSHEET_ACTION','Marksheet');
	define('PROFILE_ACTION','Profile');
	define('EDIT_ACTION','Edit');
	define('DELETE_ACTION','Delete');
	define('DETAILS_ACTION','Details');
	
	
	//Massege
	
	
	define('ATTEND_NOW_MSG','Click on the < Attend Now! > Button');
	define('FILLUP_WORNING_MSG','Fillup This Form Carefully!');
	define('ENTRY_SUCCESS_MSG','Inserted Successfully!');
	define('ENTRY_DELETE_MSG','Deleted Successfully!');
	define('ENTRY_UPDATE_MSG','Updated Successfully!');
	define('ENTRY_FAILED_MSG','Failed to Action!');
	define('ENTRY_DUPLICATE_MSG','Found Duplicate Data!');
	define('SUCCESS_MSG','Successfully Done!');
	//PAGE TITLE
	
	
	define('DASHBOARD_TITLE','Welcome to Dashboard');
	define('ADD_STUDENT_TITLE','Insert a Student');
	define('STUDENT_INFORMATION_TITLE','Student Infornation');
	define('STUDENT_MARKSHEET_TITLE','Student Marksheet');
	define('STUDENT_PROFILE_TITLE','Student Profile ');
	define('STUDENT_EDIT_TITLE','Update Student Information');
	define('ADD_STAFF_TITLE','Insert a Staff');
	define('STAFF_INFORMATION_TITLE','Staff Information');
	define('STAFF_PROFILE_TITLE','Staff Profile');
	define('STAFF_EDIT_TITLE','Update Staff Information');
	define('ADD_GUARDIAN_TITLE',' Insert a Guardian');
	define('GUARDIAN_INFORMATION_TITLE','Guardian Information');
	define('GUARDIAN_PROFILE_TITLE','Guardian Profile');
	define('GUARDIAN_EDIT_TITLE','Update Guardian Information');
	define('ADD_CLASS_TITLE','Insert a Class');
	define('CLASS_INFORMATION_TITLE','Class Information');
	define('CLASS_EDIT_TITLE','Update Class Information');
	define('ADD_SECTION_TITLE','Add Section');
	define('SECTION_INFORMATION_TITLE','Section Information');
	define('SECTION_EDIT_TITLE','Update Section Information');
	define('ADD_STUDENT_PAYMENT_NAME_TITLE','Add Student Payment Name');
	define('CREATE_STUDENT_PAYMENT_TITLE','Create Student Payment');
	define('CREATE_BULK_STUDENT_PAYMENT_TITLE','Create Student Payment (Class wise)');
	define('STUDENT_PAYMENT_TITLE','Student Fee Payment');
	define('PAYMENT_HISTORY_BY_STUDENT_TITLE','Payment History of Student');
	define('STUDENT_PAYMENT_REPORT_TITLE','Payment Report');
	define('EDIT_SUBJECT_TITLE','Update a Subject');
	define('ADD_SUBJECT_TITLE','Set a Subject');
	define('MANAGE_SUBJECT_TITLE','Manage Subject');
	define('ADD_ROUTINE_TITLE','Setup Class Routine');
	define('VIEW_ROUTINE_TITLE','View Class Routine');
	define('TODAY_STAFF_ATTENDANCE_TITLE','Today Staff Attendance');
	define('TODAY_STUDENT_ATTENDANCE_TITLE','Today Student Attendance');
	define('MONTHLY_STUDENT_ATTENDANCE_TITLE',' Monthly Student Attendance Report');
	define('MONTHLY_STAFF_ATTENDANCE_TITLE','Monthly Staff Attendance Report');
	define('STUDENT_ATTENDANCE_TITLE','View Student Attendance by Day');
	define('ADD_EXAM_TITLE','Add an Exam Name');
	define('CREATE_EXAM_TITLE','Setup an Examination');
	define('EXAM_LIST_TITLE','All Examination List');
	define('EXAM_GRADE_TITLE','Manage Examination Grade');
	define('EXAM_GRADE_ADD_TITLE','Setup Examination Grade');
	define('EXAM_GRADE_EDIT_TITLE','Edit Examination Grade');
	define('MANAGE_EXAM_MARK_TITLE','Manage Obtained Examination Marks');
	define('TABULATION_SHEET_TITLE','Examination Result Tabulation Sheet');
	define('CREATE_STAFF_PAYMENT_TITLE','Create Staff Payment');
	define('CREATE_STAFF_BULK_PAYMENT_TITLE','Create Bulk Payment');
	define('STAFF_PAYMENT_TITLE','Staff Payment');
	define('STAFF_PAYMENT_REPORT_TITLE','Staff Payment Report');
	define('ACCOUNTING_TITLE','Accounting');
	define('INCOME_TITLE','Income');
	define('EXPENSE_TITLE','Expences');
	define('LIBRARY_TITLE','Library');
	define('MANAGE_BOOKS_TITLE','Book Distribution');
	define('BOOK_LIST_TITLE','Book List');
	define('BOOK_EDIT_TITLE','Upgrade Book Information');
	define('MANAGE_DORMITORY_TITLE','Manage Dormitory');
	define('NOTICE_TITLE','Notice Board');
	define('MANAGE_NOTICE_TITLE','Manage Notice');
	define('SETTING_TITLE','System Setting');
	define('GENERAL_SETTING_TITLE','Institution Setting');
	define('USER_SETTING_TITLE','User Setting');
	define('MESSEGE_SETTING_TITLE','Messeging Setting');
	define('LANGUAGE_SETTING_TITLE','Language Setting');
	
	//FORM-> ADD STUDENT
	
	define('INSERT_NEW_PARENT_FORM','Insert a Guardian');
	define('EXIST_PARENT_FORM','Select from Exist Guardian');
	define('CLASS_NAME_FORM','Class Name');
	define('SECTION_NAME_FORM','Section Name');
	define('GUARDIAN_NAME_FORM','Guardian Name');
	define('ROLL_NUMBER_FORM','Roll Number');
	define('NAME_ENGLISH_FORM','Name (In English)');
	define('NAME_BANGLA_FORM','Name (In Bangla)');
	define('FATHER_NAME_FORM','Father Name');
	define('MOTHER_NAME_FORM','Mother Name');
	define('BIRTHDAY_FORM','Birthday');
	define('GENDER_FORM','Gender');
	define('BLOOD_FORM','Blood Group');
	define('PHONE_FORM','Phone Number');
	define('PRESENT_ADDRESS_FORM','Present Address');
	define('PARMANENT_ADDRESS_FORM','Permanent Address');
	define('EMAIL_FORM','Email');
	define('NATIONAL_ID_FORM','National ID Number');
	define('BIRTH_REGISTRATION_FORM','Birth Registration Number');
	define('RELIGION_FORM','Religion');
	define('RESPONSIBLE_TEACHER_FORM','Responsible Teacher');
	define('USERNAME_FORM','User Name');
	define('PASSWORD_FORM','Password');
	define('ADDMISSION_DATE_FORM','Addmission Date');
	define('DORMITORY_FORM','Dormitory');
	define('TRANSPORT_FORM','Transport Route');
	define('PHOTO_FORM','Photo');
	define('MALE_FORM','Male');
	define('FEMALE_FORM','Female');
	
	//Select
	define('SELECT_TEACHER_FORM','Select a Teacher');
	define('SELECT_GUARDIAN_FORM','Select a Guardian');
	define('SELECT_CLASS_FORM','Select a Class');
	define('SELECT_SECTION_FORM','Select a Section');
	define('SELECT_STUDENT_FORM','Select a Student');
	define('SELECT_MONTH_FORM','Select a Month');
	define('SELECT_YEAR_FORM','Select Year');
	define('SELECT_STAFF_FORM','Select a Staff');
	define('SELECT_DEPARTMENT_FORM','Select Department');
	
	
	//Button
	
	define('CREATE_EXAM_BUTTON','Setup Exam!');
	define('ATTEND_NOW_BUTTON','Attent Now!');
	define('NEXT_BUTTON','Next Step!');
	
	///TABLE---
	
	
	//FORM-> ADD STAFF_INFORMATION_MENU
	
	define('STAFF_NAME_FORM','Staff Name');
	define('QUALIFICATION_FORM','Edu. Qualification');
	define('DESIGNATION_FORM','Designation');
	define('DEPARTMENT_FORM','Staff Department');
	define('SALARY_FORM','Salary');
	define('JOINING_DATE_FORM','Joining Date');
	
	//FORM -> ADD GUARDIAN
	
	
	define('REALATION_FORM','Relation');
	define('PROFESSION_FORM','Profession');
	
	//FORM -> ADD CLASS
	define('TEACHER_FORM','Teacher Name');
	define('NUMERICAL_ID_FORM','Numerical Symbol');
	
	//FORM-> CREATE STUDENT_PAYMENT_MENU
	
	define('STUDENT_NAME_FORM','Student Name');
	define('PAYMENT_NAME_FORM','Payment Name');
	define('MONTH_FORM','Payment Month');
	define('FEE_AMOUNT_FORM','Fee Amount');
	define('PAID_AMOUNT_FORM','Paid Amount');
	define('RECEAVEABLE_AMOUNT_FORM','Receivable Amount');
	define('CREATE_PAYMENT_FORM','Create Payment');
	define('COMMENT_FORM','Remarks');
	define('TOTAL_AMOUNT_FORM','Total Amount');
	define('PAID_DATE_FORM','Paid Date');
	define('TO_DATE_FORM','To');
	define('FROM_DATE_FORM','From');
	define('FIND_FORM','Find Now');
	
	//FORM-> SUBJECT_MENU
	define('SUBJECT_NAME_FORM','Subject Name');
	
	//FORM-> ROUTINE
	
	define('RESET_ROUTINE_FORM','Reset Routine');
	define('ADD_ROUTINE_FORM','Setup Routine');
	
	//FORM-> ATTENDANCE_MENU
	define('PRESENT_FORM','Present');
	define('ABSENT_FORM','Absent');
	define('SET_ATTENDANCE_FORM','Set Attendance');
	define('STATUS_FORM','Status');
	define('TOTAL_FORM','Total');
	
	//FORM-> EXAM_GRADE_MENU
	define('EXAM_NAME_FORM','Exam Name');
	define('EXAM_DURATION_FORM','Exam Duration');
	define('EXAM_PASS_MARK_FORM','Pass Mark');
	define('EXAM_FULL_MARK_FORM','Full Mark');
	define('EXAM_DATE_FORM','Exam Date');
	define('CREATE_EXAM_FORM','Setup Marks');
	define('ADD_EXAM_FORM','Add Exam Name');
	define('YEAR_FORM','Year');
	
	define('GRADE_NAME_FORM','Grade Name');
	define('GRADE_MARK_UPTO_FORM','Mark Up-To');
	define('GRADE_MARK_FROM_FORM','Mark From');
	define('GRADE_POINT_FORM','Grade Point');
	define('ADD_GRADE_FORM','Add Grade');
	
	define('SUBMIT_MARK_FORM','Submit Mark');
	define('MARK_FORM','Mark');
	
	//FORM-> PAYROLL
	
	define('DUE_AMOUNT_FORM','Due Amount');
	
	//FORM->ACCOUNTING_MENU
	define('ADD_INCOME_FORM','Add Income');
	define('ADD_INCOME_CATEGORY_FORM','Add Income Category');
	define('INCOME_CATEGORY_FORM','Income Category');
	define('INVOICE_NUMBER_FORM','Invoice ID');
	define('DESCRIPTION_FORM','Description');
	
	//FORM-> LIBRARY
	
	define('BOOK_ID_FORM','Book ID');
	define('BOOK_NAME_FORM','Book Name');
	define('GIVING_DATE_FORM','Giving Date');
	define('RETURNING_DATE_FORM','Returning Date');
	define('RETURN_FORM','Return');
	
	
	define('BOOK_AUTHOR_FORM','Author');
	define('BOOK_PRICE_FORM','Price');
	define('ADD_BOOK_FORM','Add Book');
	
	//FORM-> NOTICE_MENU
	define('NOTICE_TITLE_FORM','Notice Title');
	define('NOTICE_DESCRIPTION_FORM','Notice Description');
	
	//FORM-> SETTING
	define('INSTITUTION_NAME_FORM','Institution Name');
	define('INSTITUTION_MOTO_FORM','Institution Moto');
	define('ESTABLISHMENT_DATE_FORM','Establishment Date');
	define('BOARD_FORM','Board');
	define('DISTRICT_FORM','District');
	define('CITY_FORM','City');
	define('INSTITUTION_CODE_FORM','Institution Code');
	define('ACADEMIC_YEAR_FORM','Academic Year');
	
?>