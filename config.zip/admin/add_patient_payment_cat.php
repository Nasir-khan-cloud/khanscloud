<?php ob_start();?>
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php 
			$msg="";
				if(isset($_POST['submit_payment_cat_name']))
				{
					$name=$_POST['payment_cat_name'];
					$insert_payment="INSERT INTO patient_payment_head(name) VALUES('$name')";
					if(mysqli_query( $connect,$insert_payment))
					{$msg="Successfully Added";}
				else{$msg= "Something went wrong";}
					
				}
				
				if(isset($_GET['payment_id']))
				{
					$payment_id=$_GET['payment_id'];
					$delete_query="DELETE FROM patient_payment WHERE payment_id='".$payment_id."'";
					if(mysqli_query( $connect,$delete_query))
					{$msg="Successfully Deleted"; header('location: add_patient_payment_cat.php');exit;}
				else{$msg="Could not deleted";}
					
				}
			
			?>
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Add Patient Payment</h2>
							</td>
							<td><?php echo $msg;?></td>
						</tr>
					</table>
					
				<table>
						<tr><form method="POST">
							<td>
								<textarea colspan="4" name="payment_cat_name"></textarea>
							</td><td>
									<input name="submit_payment_cat_name" class="submit" type="submit" value="Add Payment Name"></td>
							
								</td>
						</form></tr>
					
				</table>
				
				
				
				
		<!---- Second form Start --->
		
					<table>
					<form method="POST" media="all">
							<th class="table-header">SN</th>
							<th class="table-header">Name</th>
							<th class="table-header">Action</th>
						<?php
							
							$sn=0;
							$payment_info_query="SELECT* FROM patient_payment_head";
							$payments=mysqli_query($connect,$payment_info_query);
							foreach($payments as $payment): $sn++; ?>
							<tr>
								<td><?php echo $sn?></td>
								<td><?php echo $payment['name'];?> </td>
								<td> <a onclick="return confirm('Are you sure to delete ??');" href="<?php echo "add_student_payment_cat.php?action=delete&payment_id=".$payment['payment_id'];?>">Delete</a> </td>
							</tr>
						<?php endforeach;?>
				</table>
					
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>