
<?php
	$duplicate=false;
	?>

<!DOCTYPE html>
<html>
	<head>	
	<style>	

		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
			
			<?php
				if(isset($_POST['doctor_submit']))
				{
					$doctor_name=$_POST['doctor_name'];
					$specialist=$_POST['specialist'];
					$department_id=$_POST['department_id'];
					$doctor_education=$_POST['doctor_education'];
					$doctor_birthday=$_POST['doctor_birthday'];
					$doctor_blood=$_POST['doctor_blood'];
					$doctor_address=$_POST['doctor_address'];
					$doctor_email=$_POST['doctor_email'];
					$doctor_phone=$_POST['doctor_phone'];
					$doctor_gender=$_POST['doctor_gender'];
					$doctor_password=$_POST['doctor_password'];
					$doctor_username=$_POST['doctor_username'];
					$joining_date=$_POST['joining_date'];
					
					
					
					//Code for Uploading Image
					$errors= array();
				  $file_name = $_FILES['doctor_photo']['name'];
				  $file_size =$_FILES['doctor_photo']['size'];
				  $file_tmp =$_FILES['doctor_photo']['tmp_name'];
				  $file_type=$_FILES['doctor_photo']['type'];
				  $file_ext=strtolower(end(explode('.',$_FILES['doctor_photo']['name'])));
				  
				  /*$expensions= array("JPG","JPEG","PNG");
				  
				  if(in_array($file_ext,$expensions)=== false){
					 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
				  }*/
				  
				  if($file_size > 2000000097152){
					 $errors[]='File size must be excately 2 MB';
				  }
				  $new_logo_name="photo_".str_replace(" ","_",$doctor_name).$specialist.".".$file_ext;
				  if(empty($errors)==true){
					 $photo_destination=DIR_DOCTOR_IMAGE.$new_logo_name;
					  
				  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
					 $doctor_photo="image/teacher/".$new_logo_name;
				  }else{
					 print_r($errors);
				  }
				  
				  if($duplicate!=true)
				  {
					  $doctor_submit_query="INSERT INTO doctor(name,education,birthday,sex,blood_group,address,phone,email,password,specialist,join_date,photo,department_id)
					  VALUES('$doctor_name','$doctor_education','$doctor_birthday','$doctor_gender','$doctor_blood','$doctor_address','$doctor_phone','$doctor_email','$doctor_password','$specialist','$joining_date','$doctor_photo','$department_id')";
					  
					if(mysqli_query($connect,$doctor_submit_query))
						
					{
						$msg="Staff Successfully Inserted";
					}
					else{
						$msg=ENTRY_FAILED_MSG;
					}
					
				  }
				  else{
					  $msg=ENTRY_DUPLICATE_MSG;
				  }
				}
			?>
			
			
			
				<div>	
					<table>
						<tr><td><h2><?php echo ADD_STAFF_TITLE;?></h2></td></tr>
						<tr><td><h4><?php echo $msg;?></h4></td></tr>
					</table>
					<table class="insertion_table">
							
					<form method="POST"  enctype="multipart/form-data">
					
							<tr>
								<td>Department</td>
								<td>
									<select name="department_id">
										<option value="<?php echo "?department_id=".""?>">Select a Department</option>
											<?php 
												$select_department_query="SELECT* FROM department";
												$result_departments=mysqli_query($connect,$select_department_query);
												while($department=mysqli_fetch_array($result_departments,MYSQLI_BOTH)){?>
												<option value="<?php echo $department['department_id']?>"><?php echo $department['name'];?></option>
												
											
											<?php } ?>
									</select>
								</td>
							</tr>
						
						
							<tr>
								<td><?php echo STAFF_NAME_FORM;?></td>
								<td><input required type="text" name="doctor_name" class="info_input" id="doctor_name"></td>
							</tr>
							<tr>
								<td><?php echo QUALIFICATION_FORM;?></td>
								<td><input  type="text" name="doctor_education" class="info_input" id="doctor_name"></td>
							</tr>
						
							<tr>
								<td><?php echo "Specialist";?></td>
								<td><input  type="text" name="specialist" class="info_input" id="doctor_designation"></td>
							</tr>
							<tr>
								<td><?php echo BIRTHDAY_FORM;?></td>
								<td><input type="date" name="doctor_birthday" class="info_input" id="doctor_birthday"></td>
							</tr>
							
							<tr>
								<td><?php echo GENDER_FORM;?></td>
								<td>
									<select name="doctor_gender" class="info_input" id="doctor_gender">
										<option value="male"><?php echo MALE_FORM;?></option>
										<option value="female"><?php echo FEMALE_FORM;?></option>									
									</select>
								</td>
							</tr>
							<tr>
								<td><?php echo BLOOD_FORM;?></td>
								<td><input type="text" name="doctor_blood" class="info_input" id="doctor_blood"></td>
							</tr>
							<tr>
								<td><?php echo PHONE_FORM;?></td>
								<td><input  type="text" name="doctor_phone" class="info_input" id="doctor_phone"></td>
							</tr>
							<tr>
								<td><?php echo PRESENT_ADDRESS_FORM;?></td>
								<td><input  type="text" name="doctor_address" class="info_input" id="doctor_address"></td>
							</tr>
							<tr>
								<td><?php echo EMAIL_FORM;?></td>
								<td><input  type="text" name="doctor_email" class="info_input" id="doctor_email"></td>
							</tr>
							<tr>
								<td><?php echo USERNAME_FORM;?></td>
								<td><input  type="text" name="doctor_username" class="info_input" id="doctor_username"></td>
							</tr>
							<tr>
								<td><?php echo PASSWORD_FORM;?></td>
								<td><input  type="password" name="doctor_password" class="info_input" id="doctor_password"></td>
							</tr>
							<tr>
								<td><?php echo JOINING_DATE_FORM;?></td>
								<td><input  type="date" name="joining_date" class="info_input" id="doctor_salary"></td>
							</tr>
							<tr>
								<td><?php echo PHOTO_FORM;?></td>
								<td><input  type="file" name="doctor_photo" class="info_input" id="doctor_photo"></td>
							</tr>
							<tr>
								<td colspan="2"><input   type="submit" value="Add Staff" name="doctor_submit" class="info_input" id="doctor_submit"></td>
							</tr>
						
							
					</form>
						</table>
				
				
				</div>
			
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>




<?php
	
	
	if(isset($_POST['doctor_submit']))
	{
		$doctor_name=$_POST['doctor_name'];
		$doctor_designation=$_POST['doctor_designation'];
		$doctor_education=$_POST['doctor_education'];
		$doctor_birthday=$_POST['doctor_birthday'];
		$doctor_blood=$_POST['doctor_blood'];
		$doctor_address=$_POST['doctor_address'];
		$doctor_email=$_POST['doctor_email'];
		$doctor_phone=$_POST['doctor_phone'];
		$doctor_gender=$_POST['doctor_gender'];
		$doctor_password=$_POST['doctor_password'];
		$doctor_salary=$_POST['doctor_salary'];
		$doctor_dept=$_POST['department_id'];
		$doctor_username=$_POST['doctor_username'];
		$joining_date=date("Y/m/d");
		
		
		$doctor_info_query="SELECT* FROM teacher";
		$teachers=mysqli_query($connect,$doctor_info_query);
		foreach($teachers as $teacher):	
			if(strcmp($doctor_email,$teacher['email'])==0 ){$duplicate=true; echo "Duplicate Email";}	
			if(strcmp($doctor_phone,$teacher['phone'])==0 ){$duplicate=true; echo "Duplicate Phone";}		
		endforeach;
		
		
		
		//Code for Uploading Image
		$errors= array();
      $file_name = $_FILES['doctor_photo']['name'];
      $file_size =$_FILES['doctor_photo']['size'];
      $file_tmp =$_FILES['doctor_photo']['tmp_name'];
      $file_type=$_FILES['doctor_photo']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['doctor_photo']['name'])));
      
      /*$expensions= array("JPG","JPEG","PNG");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }*/
      
      if($file_size > 2000000097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $new_logo_name="photo_".str_replace(" ","_",$doctor_name).$doctor_designation.".".$file_ext;
      if(empty($errors)==true){
		 $photo_destination=DIR_doctor_IMAGE.$new_logo_name;
		  
	  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
		 $doctor_photo="image/teacher/".$new_logo_name;
      }else{
         print_r($errors);
      }
	  
	  if($duplicate!=true)
	  {
		  $doctor_submit_query="INSERT INTO teacher(name,education,birthday,sex,blood_group,address,phone,email,password,designation,join_date,photo)
		  VALUES('$doctor_name','$doctor_education','$doctor_birthday','$doctor_gender','$doctor_blood','$doctor_address','$doctor_phone','$doctor_email','$doctor_password','$doctor_designation','$joining_date','$doctor_photo')";
		  
		mysqli_query($connect,$doctor_submit_query);
		
		header('location: doctor_information.php');
		exit;
	  }
		
	}
	
	


?>

	
	<script>
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




</script>