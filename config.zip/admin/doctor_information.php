


	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php 

			if(isset($_GET['doctor_id']))
			{
				$success="";

				if(isset($_GET['action']))
				{

				$id=$_GET['doctor_id'];

				$shop_delete_query = "DELETE FROM teacher WHERE doctor_id='".$id."'";
				if(mysqli_query($connect,$shop_delete_query)){
				echo "Teacher=>".$id." has been Deleted";}
					else{ echo "Something went wrong";}
				}	
			}	
			?>
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr><td><h2>Doctor Information</h2></td></tr>
						<tr>
							<td>
								<input class="add_button" type="button" onclick="parent.location='<?php echo "add_doctor.php";?>'" value="Add Doctor"></td>
							
							</td>
						</tr>
					</table>
				
					<table class="table table-bordered datatable" id="table_export">
						<?php $success;?>
						<th class="table-header"><div>SN.</div></th>
						<th class="table-header"><div>Photo</div></th>
						<th class="table-header"><div>Name</div></th>
						<th class="table-header"><div>Specialist</div></th>
						<th class="table-header"><div>Address</div></th>
						<th class="table-header"><div>Email</div></th>
						<th class="table-header"><div>Phone</div></th>
						<th class="table-header"><div>Options</div></th>
						
											
						<?php
						$sn=0;
						$doctor_info_query="SELECT* FROM doctor";
						$doctors=mysqli_query($connect,$doctor_info_query);
						foreach($doctors as $doctor): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>
								<td><img style="height:40px;width:40px;" src="<?php echo BASE_URL.$doctor['photo'];?>" /></td>
								<td><?php echo $doctor['name'];?></td>
								<td><?php echo $doctor['specialist'];?></td>
								<td><?php echo $doctor['address'];?></td>
								<td><?php echo $doctor['email'];?></td>
								<td><?php echo $doctor['phone'];?></td>
								<td>
								
									<select onchange="location=this.value;" type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
										Action
										<option>
											<a href="#">Action</a>
										</option>
										<option value="<?php echo 'doctor_profile.php?doctor_id='.$doctor['doctor_id'];?>">Profile</option>
										
										<!-- STUDENT EDITING LINK -->
										<option value="<?php echo 'doctor_edit.php?doctor_id='.$doctor['doctor_id'];?>">Edit</option>
										
										<hr>
										<!-- STUDENT DELETION LINK -->
										<option value="<?php echo '?doctor_id='.$doctor['doctor_id'].'&action=delete';?>">Delete</option>
										
									</select>
								</td>
							</tr>
						<?php endforeach;?>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	
