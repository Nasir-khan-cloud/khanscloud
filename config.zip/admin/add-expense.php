
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			
			<?php
				
				if(isset($_POST['expense_submit']))
				{
					
					$category=$_POST['exp_cat'];
					$name=$_POST['name'];
					$invoice_num=$_POST['invoice_num'];
					$description=$_POST['description'];
					$amount=$_POST['amount'];
					$date=date("Y/m/d");
					
					$expense_insert_query="INSERT INTO expense(expense_category_id,title,description,amount,payment_date,invoice_num)VALUES('$category','$name','$description','$amount','$date','$invoice_num')";
					
					if(mysqli_query($connect, $expense_insert_query)){
						$msg= "Records were Addes successfully.";
						echo $msg;
						header('location: expense.php');
						exit;
					}
					else
					{
						$msg= "Something went wrong";
						echo $msg;
						
						
					}
					
				}
			?>
		
			<div id="d-wrapper">
				<div>
				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2>Add Expense</h2></td></tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
						
							<tr>
								<td>Expanse Category</td>
								<td>
									<select type="text" name="exp_cat" class="student_info_input" id="exp_cat">
										<?php
										$expense_category_query="SELECT* FROM expense_category";
										$categories=mysqli_query($connect,$expense_category_query);
										foreach($categories as $category): ?>
										<option value="<?php echo $category['expense_category_id']?>"><?php echo $category['name']?></option>
										<?php endforeach;?>
									
									</select>
								</td>
								
							</tr>
							
							<tr>
								<td>Invoice Number</td>
								<td><input required type="text" name="invoice_num" class="class_info_input" id="invoice_num"></td>
							</tr>
							
							<tr>
								<td>Title</td>
								<td><input required type="text" name="name" class="class_info_input" id="name"></td>
							</tr>
							<tr>
								<td>Description</td>
								<td><input required type="text" name="description" class="class_info_input" id="description"></td>
							</tr>
							<tr>
								<td>Amount</td>
								<td><input required type="number" name="amount" class="class_info_input" id="amount"></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" value="Add Subject" name="expense_submit" class="class_info_input" id="class_submit"></td>
							</tr>
					</form>
						</table>				
				</div>
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

