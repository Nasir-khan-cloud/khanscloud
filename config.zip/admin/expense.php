

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			
			
			<?php 
					$msg=""; 
					if(isset($_GET['action'])&& isset($_GET['id'])){
					$action=$_GET['action'];
					$id=$_GET['id'];
					$delete_query="DELETE FROM expense WHERE payment_id='".$id."'";
					
					if(mysqli_query($connect, $delete_query)){
						$msg= "Records were Deleted successfully.";
						header('location: expense.php');
						exit;
					}
					else
					{
						$msg= "Something went wrong";
						
						
					}
				}
				
				$from_date=date("y/m/d");
				$to_date=date("y/m/d");
				
				if(isset($_POST['submit_report']))
				{
					
					$from_date=$_POST['from_date'];
					$to_date=$_POST['to_date'];
					
				}
			?>
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Expances Record</h2>
							</td>
						</tr>
					<form method="POST">
							<tr>
							
								<td>From 
									<input type="date" name="from_date" value="<?php echo $from_date;?>" >
								</td>
								<td>To
									<input type="date" name="to_date" value="<?php echo $to_date;?>">
								</td>
								<td>
									<input class="add_button" type="submit" name="submit_report">
								</td>
							</tr>
						</form>
					</table>
					<table class="select_bar" id="bar">
					
						<?php $success;$total_expense=0; ?>
						<th class="table-header">SN.</th>
						<th class="table-header">Expanse Category</th>
						<th class="table-header">Invoice Number</th>
						<th class="table-header">Title</th>
						<th class="table-header">Description</th>
						<th class="table-header">Amount</th>
						<th class="table-header">Expanse Date</th>
						<th class="table-header">Action</th>				
						<?php
						$sn=0;
						$expense_query="SELECT* FROM expense  WHERE payment_date>='".$from_date."' AND payment_date<='".$to_date."'";
						$expenses=mysqli_query($connect,$expense_query);
						foreach($expenses as $expense): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>
								<td><?php $class_query="SELECT name FROM expense_category WHERE expense_category_id='".$expense['expense_category_id']."'";
									$details=mysqli_query($connect,$class_query);												
									$expense_cat=mysqli_fetch_array($details,MYSQLI_BOTH);
									echo $expense_cat['name'];?></td>					
								
								<td><?php echo $expense['invoice_num'];?></td>
								<td><?php echo $expense['title'];?></td>
								<td><?php echo $expense['description'];?></td>
								<td><?php $total_expense=$total_expense+$expense['amount']; echo $expense['amount'];?></td>
								<td><?php echo $expense['payment_date'];?></td>
								
								<td>
									
									<div class="btn-group">
										<a href="<?php echo ADMIN_URL."expense.php?action=delete&id=".$expense['payment_id'];?>" onclick="return confirm('Are you sure??');">Delete</a>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
						
							<tr><h3> Total Expenses : <?php echo $total_expense; ?></h3></tr>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

			
	<script>
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




</script>
