
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php 
			
				if(isset($_GET['department_id']))
				{
					$department_id=$_GET['department_id'];
				}
				if(isset($_POST['payment_create'])){
					$payment_head_id=$_POST['payment_head_id'];
					$amount=$_POST['payment_amount'];
					$patient_id=$_POST['patient_id'];
					$date=date("Y/m/d");
					
					
					$payment_details_query="INSERT INTO patient_payment_details(created_date, patient_id, amount, payment_head_id, status)
					VALUES ('$date','$patient_id','$amount','$payment_head_id','0')";
					
					if(mysqli_query($connect,$payment_details_query)){
					$msg= ENTRY_SUCCESS_MSG;}
					else{
						$msg=ENTRY_FAILED_MSG;
					}
					
					
					
				}
			
			?>
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Create Payment </h2>
							</td><td>
									<input class="add_button" type="button" onclick="parent.location='<?php echo "add_patient_payment_cat.php"?>'" value="Add Payment Head"></td>
							
								
					</table>
					
				<table>
					<tr>
						<td>Department</td>
						<td>
							<select onchange="location=this.value;" type="text" name="class_id" class="student_info_input" id="header_selects">
								<option value="<?php echo 'create_student_payment.php'; ?>">Select a Department</option>
								<?php
								$class_query="SELECT* FROM department";
								$departments=mysqli_query($connect,$class_query);
								foreach($departments as $department): ?>
								<option <?php if(isset($_GET['department_id'])){if($department['department_id']==$_GET['department_id']){echo "selected";}}?>  value="<?php echo 'create_patient_payment.php?department_id='.$department['department_id']?>"><?php echo $department['name']?></option>
								<?php endforeach;?>
							
							</select>
						</td>
					</tr>
					<?php if(isset($_GET['department_id'])){ ?>
					<form method="POST" media="all">
					
						<tr>
							<td>Patient Name</td>
							<td>
								
								<div class="btn-group">
									<select type="button" name="patient_id" class="btn btn-default btn-sm dropdown-toggle" id="header_selects">
										<option>Select a Patient</option>
										<?php
										$patient_name_query="SELECT* FROM patient WHERE department_id='".$department_id."'";
										$patients=mysqli_query($connect,$patient_name_query);
										foreach($patients as $patient): ?>
										<option <?php if(isset($_GET['patient_id'])){if($patient['patient_id']==$_GET['patient_id']){echo "selected";}}?>  value="<?php echo $patient['patient_id']?>"><?php echo $patient['name']."-(".$patient['reg_id'].")";?></option>
										<?php endforeach;?>
									</select>
								</div>
							</td>
						</tr>
						<tr>
							<td>Payment Name Head</td>
							<td>
								<select type="text" name="payment_head_id" class="student_info_input" id="header_selects">
									<?php
									$payment_query="SELECT* FROM patient_payment_head";
									$payments=mysqli_query($connect,$payment_query);
									foreach($payments as $payment): ?>
									<option  value="<?php echo $payment['payment_id']?>"><?php echo $payment['name']?></option>
									<?php endforeach;?>
								
								</select>
							</td>
						</tr>
						<tr>
							<td>Amount</td>
							<td>
								<input type="number" name="payment_amount" id="header_selects">
							</td>
						</tr>
						<tr>
							<td>Create Payment</td>
							<td colspan="2">
								<input class="add_button" type="submit" name="payment_create" value="Create Payment">
							</td>
						</tr>
					</form>
					<?php } ?>
				</table>
				
				
		<!---- Second form Start --->
		

				
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>