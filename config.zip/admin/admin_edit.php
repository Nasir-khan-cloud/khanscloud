<?php ob_start();?>
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		
	<?php
	
		
		if(isset($_GET['admin_id']))
		{
			$admin_id=$_GET['admin_id'];
			$admin_details="SELECT* FROM admin WHERE admin_id='".$admin_id."'";
			$details=mysqli_query($connect,$admin_details);												
			$admin=mysqli_fetch_array($details,MYSQLI_BOTH);
			$name=$admin['name'];
			$email=$admin['email'];
			$username=$admin['username'];
			$password=$admin['password'];	
			$level=$admin['level'];	
			
			
		}
		if(isset($_POST['admin_submit']))
		{
			
			$admin_name=$_POST['admin_name'];
			$admin_email=$_POST['admin_email'];
			$admin_username=$_POST['admin_username'];
			$admin_password=$_POST['admin_password'];
			$admin_level=$_POST['admin_level'];
			
			$admin_update_query="UPDATE admin SET name= '$admin_name',email= '$admin_email',username= '$admin_username',password= '$admin_password',level= '$admin_level' WHERE admin_id='".$admin_id."'";
			
			if(mysqli_query($connect, $admin_update_query)){
				$msg= "Records were updated successfully.";
				echo $msg;
				header('location: users.php');
				exit;
			}
			else
			{
				$msg= "Something went wrong";
				echo $msg;
				
				
			}
			
		}
	?>
		
		
		
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>
				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2>admin Information Update</h2></td></tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
						
							<tr>
								<td>Name</td>
								<td><input value="<?php echo $name;?>" required type="text" name="admin_name" class="admin_info_input" id="admin_name"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input value="<?php echo $email;?>" required type="text" name="admin_email" class="admin_info_input" id="admin_email"></td>
							</tr>
							<tr>
								<td>Username</td>
								<td><input value="<?php echo $username;?>" required type="text" name="admin_username" class="admin_info_input" id="admin_username"></td>
							</tr>
								<td>Password</td>
								<td><input value="<?php echo $password;?>" required type="password" name="admin_password" class="admin_info_input" id="admin_password"></td>
							</tr>
								<td>Level</td>
								<td><input value="<?php echo $level;?>" required type="password" name="admin_level" class="admin_info_input" id="admin_level"></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" value="Update Information" name="admin_submit" class="admin_info_input" id="admin_submit"></td>
							</tr>
					</form>
						</table>				
				</div>
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

