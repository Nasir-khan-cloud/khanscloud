
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<h1>UNDER CONSTRUCTION</h1>	

				<table style="padding: 0px; margin: 0px;">
					<tr><td>yasir arafat shuvo</td>
					<?php for($i=0;$i<31;$i++){?>
					<td><input disabled type="checkbox" checked></td>
					<?php } ?><td>Total</td>
					</tr>
					<tr>
					<td>yasir arafat shuvo</td>
					<?php for($i=1;$i<32;$i++){?>
					<td><?php echo $i;?></td>
					<?php } ?>
					
					</tr>
				<table>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>