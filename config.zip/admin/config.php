<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/hospital/admin/');

define('BASE_URL', 'http://localhost/hospital/');
define('ADMIN_URL', 'http://localhost/hospital/admin/');

//Directory

define('DIR_LANGUAGE', 'C:/xampp/htdocs/hospital/language/');
define('DIR_BASE', 'C:/xampp/htdocs/hospital/hospital/');

define('DIR_SYSTEM_IMAGE', 'C:/xampp/htdocs/hospital/image/');
define('DIR_PATIENT_IMAGE', 'C:/xampp/htdocs/hospital/image/patient/');
define('DIR_DOCTOR_IMAGE', 'C:/xampp/htdocs/hospital/image/doctor/');
define('DIR_ADMIN_IMAGE', 'C:/xampp/htdocs/hospital/image/admin/');
define('DIR_THEME_IMAGE', 'C:/xampp/htdocs/hospital/admin/style/images/');



// DB
	$connect = mysqli_connect('localhost', 'root', "",'hospital'); if(!$connect){die('Unable to connect to Admin Database');}

	
?>
