
<!DOCTYPE html>
<html>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<table style="margin-bottom:5px;">
					<tr><td><h2><?php echo DASHBOARD_TITLE;?></h2></td></tr>
				</table>

			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

<script type='text/javascript'>

$(document).ready(function() {
    $('#calendar').fullCalendar({
        googleCalendarApiKey: 'AIzaSyDS-1BLKqa7TLIu49TNaOMt8dgM2aOlsgk',
        events: {
            googleCalendarId: 'abcd1234@group.calendar.google.com',
            className: 'gcal-event' // an option!
        }
    });
});

</script>