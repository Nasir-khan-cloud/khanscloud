<?php
	require_once 'config.php';
	session_start();
	
	
	//Starting Language setup
	if(isset($_GET['lang']))
	{
		$_SESSION['lang']=$_GET['lang'];
	}
	
	
	if(isset($_SESSION['lang']))
	{
		if($_SESSION['lang']=='en')
		{
			$lang=DIR_LANGUAGE.'english.php';
		}
		else if($_SESSION['lang']=='bn')
		{
			$lang=DIR_LANGUAGE.'bangla.php';
		}
	}
	else
	{
		$lang=DIR_LANGUAGE.'english.php';
	}
	require_once ($lang);
	
	//end of language setup
	
	
	
	
	if(isset($_SESSION['loged-in']))
	{
		$loggedin=$_SESSION['loged-in'];
		$user_full_name=$_SESSION['user_full_name'];
		$user_id=$_SESSION['user_id'];
	}
	else
	{
		$loggedin=0;
		ob_start();
		header('location:'.BASE_URL.'login.php');
		exit();
		
		
	}
	
	$app_details_query= "SELECT* FROM setting";
	$app_details=mysqli_query($connect,$app_details_query);											
	$app_detail=mysqli_fetch_array($app_details,MYSQLI_BOTH);

	$user_details_query="SELECT* FROM admin WHERE admin_id='".$user_id."'";
	$user_details=mysqli_query($connect,$user_details_query);
	$user_detail=mysqli_fetch_array($user_details,MYSQLI_BOTH);
	
 ?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<style>
	<link rel="stylesheet" href="style/style.css" type="text/css"/>
	</style>
	<title><?php echo $app_detail['system_title'];?></title>
</head>
<body onload="startTime();">
	<header>
		<div id="hcontainer">
		<div><b><h1 style="text-align: center; font-size: 30px; font-family: Copperplate Gothic light; color: indigo;text-decoration: underline;"><?php echo $app_detail['system_title'];?></h1></b></div>
		<div style="float:left;">
			<img style="margin-top: 3px;width: 80px; height: 80px;" src="<?php echo BASE_URL.$app_detail['logo'];?>">
		</div>
		
		<!--
		<div class="header_clock">
			<h3 id="time"><h3>
		</div>
		
		-->
		
		<!-- Navmenu start -->
	
		
		<div class="header_dropdown_matrix" style="float:left;">
			<li class="header_dropdown">
			  <button class="header_dropbtn">Languages</button>
			  <div class="header_dropdown-content">
				<a href="<?php echo '?lang=en';?>"><?php echo "English" ?></a>
			
				<!--<a href="<?php echo '?lang=bn';?>">বাংলা</a> -->
				<a href="#">বাংলা</a>
			  </div>
			</li>
		</div>
		
		
		<div class="header_dropdown_matrix" style="float:left;">
			<li class="header_dropdown">
			  <button class="header_dropbtn">Help Line</button>
			  <div class="header_dropdown-content">
				<a href="<?php echo BASE_URL.'admin/user_manual.php'; ?>"><?php echo "User Manual" ?></a>
				
				<a href="<?php echo BASE_URL.'admin/contact_developer.php'; ?>"><?php echo "Contact Developer";?></a>
			  </div>
			</li>
		</div>
		
		<div class="header_dropdown_matrix" style="float:left;">
			<li class="header_dropdown">
			  <button class="header_dropbtn">Initial Setup</button>
			  
			  <div class="header_dropdown-content">
				<a href="<?php echo BASE_URL.'admin/general_setting.php'; ?>">General Setting</a>
				<a href="<?php echo BASE_URL.'admin/users.php'; ?>">User Setting</a>
				<a href="#">Massege Setting</a>
				<a href="#">Language Setting</a>
				</div>
			</li>
		</div>
		
		
		<!-- logout section  -->
		<div style="float:right;">
			
			<li class="header_dropdown">
			  <button class="header_dropbtn"> <?php echo "Hi!-".$user_detail['name'];?></button>
			  <div class="header_dropdown-content">
				<a href="#"><?php echo $user_detail['email']; ?></a>
				<hr>
				<a href="<?php echo BASE_URL.'logout.php'; ?>"><?php if($loggedin==1){echo "Logout";}?></a>
			  </div>
			</li>
		</div>
		<div style="clear:both;"></div>
		</div>
	</header>
	<div style="width: 100%; border: 1px solid #ddd; background: linear-gradient(#fff, #ddd);">
		<div style="float:left;width:18%;background: linear-gradient(#fff, #ddd);" class="header_clock">
			<h2 style="color: blue;" id="time"></h2>
		</div>
		<div style="float:left;width: 81%;background: linear-gradient(#fff, #ddd);">
			<marquee>
				<?php $i=0;
				$notice_query="SELECT* FROM noticeboard order by notice_id desc limit 2";
				$notices=mysqli_query($connect,$notice_query );
				foreach($notices as $notice): ?>
				<h3 style="float:left;"><?php echo ++$i.") =>". $notice['notice'];?></h3>
				<?php endforeach;?>
			</marquee>
		</div>
	</div>
	<div style="clear:both;"></div>
</body>

<script>
function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('time').innerHTML =
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
</html>
