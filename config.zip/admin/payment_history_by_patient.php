

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php			
			$msg="";
				
				
				if(isset($_GET['department_id'])){
					$department_id=$_GET['department_id'];
				}
			?>
			
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Payment History by Patient</h2>
							</td>
						</tr>
						<tr><td><h2><? echo $msg;?></h2></td></tr>
				
						<tr>
							<td>Department</td>
							<td>Patient Name</td>
						</tr>
				
						<tr>
							<td>
								<select onchange="location=this.value;" type="text" name="class_id" class="student_info_input" id="header_selects">
									<option value="<?php echo 'create_student_payment.php'; ?>">Select a Department</option>
									<?php
									$class_query="SELECT* FROM department";
									$departments=mysqli_query($connect,$class_query);
									foreach($departments as $department): ?>
									<option <?php if(isset($_GET['department_id'])){if($department['department_id']==$_GET['department_id']){echo "selected";}}?>  value="<?php echo '?department_id='.$department['department_id']?>"><?php echo $department['name']?></option>
									<?php endforeach;?>
								
								</select>
							</td>
							<?php if(isset($_GET['department_id'])){ ?>
							<td>
								
								<div  class="btn-group">
									<select onchange="location=this.value;" type="button" name="patient_id" class="btn btn-default btn-sm dropdown-toggle" id="header_selects">
										<option>Select a Patient</option>
										<?php
										$patient_name_query="SELECT* FROM patient WHERE department_id='".$department_id."'";
										$patients=mysqli_query($connect,$patient_name_query);
										foreach($patients as $patient): ?>
										<option <?php if(isset($_GET['patient_id'])){if($patient['patient_id']==$_GET['patient_id']){echo "selected";}}?>  value="<?php echo '?department_id='.$department_id.'&patient_id='.$patient['patient_id'];?>"><?php echo $patient['name']."-(".$patient['reg_id'].")";?></option>
										<?php endforeach;?>
									</select>
								</div>
							</td>
							<?php }?>
						</tr>
					</table>
					
					
					
					<?php
					if(isset($_GET['patient_id']))
					{ ?>
					<table class="select_bar" id="bar">
						<form method="POST">
							<th class="table-header">Payment Name</th>
							<th class="table-header">Payment Amount</th>
							<th class="table-header">Paid Amount</th>
							<th class="table-header">Due Amount</th>
							<th class="table-header">Paid Date</th>
							<th class="table-header">Comment</th>
						<?php
							$total_amount=0;
							$total_paid=0;
							$total_due=0;
							$patient_id=$_GET['patient_id'];
							$payment_query="SELECT ppd.*,  pph.name as payment_head FROM patient_payment_details ppd INNER JOIN patient_payment_head pph ON(pph.payment_id=ppd.payment_head_id) WHERE patient_id='".$patient_id."' AND status=1";
							$payments=mysqli_query($connect,$payment_query);
							foreach($payments as $payment):
						?>
							<tr>
								<td><?php echo $payment['payment_head'];?></td>
								<td>
									<?php $total_amount+=$payment['amount']; echo $payment['amount'];?>
								</td>
								<td>
									<?php $total_paid+=$payment['paid'];  echo $payment['paid'];?>
								</td>
								<td>
									<?php  echo $due=$payment['amount']-$payment['paid'];$total_due+=$due;?>
								</td>
								<td>
									<?php  echo $payment['payment_date'];?>
								</td>
								<td>
									<textarea name="comment[]" type="text"><?php  echo $payment['remark'];?></textarea>
								</td>
							</tr>
							<?php endforeach; ?>
							<tr>
								<td><h3>Total</h3></td>
								<td><h3><?php echo "Amount : ".$total_amount;?></h3></td>
								<td><h3><?php echo "Paid : ".$total_paid;?></h3></td>
								<td><h3><?php echo "Due : ".$total_due;?></h3></td>
							</tr>
						</form>
						<tr></tr>
					</table>
						<?php }?>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

			
