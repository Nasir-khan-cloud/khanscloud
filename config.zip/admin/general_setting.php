
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
		<meta http-equiv="Content-Type" content="text/html" charset="utf8_unicode_ci" />
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		
		<?php
			if(isset($_POST['parent_submit']))
			{
				
				$system_name=$_POST['system_name'];
				$system_title=$_POST['system_title'];
				$establish_date=$_POST['establish_date'];
				$district=$_POST['district'];
				$city=$_POST['city'];
				$phone=$_POST['phone'];
				$email=$_POST['email'];
				$address=$_POST['address'];
				$language=$_POST['language'];
				$currency=$_POST['currency'];
				
				
				
				if(isset($_FILES['logo'])){
				$errors= array();
			  $file_name = $_FILES['logo']['name'];
			  $file_size =$_FILES['logo']['size'];
			  $file_tmp =$_FILES['logo']['tmp_name'];
			  $file_type=$_FILES['logo']['type'];
			  $file_ext=strtolower(end(explode('.',$_FILES['logo']['name'])));
			  
			  /*$expensions= array("JPG","JPEG","PNG");
			  
			  if(in_array($file_ext,$expensions)=== false){
				 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
			  }*/
			  
			  if($file_size > 2000000097152){
				 $errors[]='File size must be excately 2 MB';
			  }
			  $new_logo_name="photo_".str_replace(" ","_",$file_name).".".$file_ext;
			  if(empty($errors)==true){
				 $photo_destination=DIR_SYSTEM_IMAGE.$new_logo_name;
				  
			  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
				 $logo="image/".$new_logo_name;
			  }else{
				 print_r($errors);
			  }
			}
				
				
				$setting_query="UPDATE setting SET system_name= '$system_name',system_title= '$system_title',establish_date='$establish_date',board='$board',district='$district',city='$city',ins_code='$ins_code',logo='$logo',address= '$address',phone= '$phone',email= '$email',language= '$language',currency= '$currency',academic_year= '$academic_year' WHERE system_id=1";
				
				if(mysqli_query($connect, $setting_query)){
					$msg= "Records were updated successfully.";
					echo $msg;
				}
				else
				{
					$msg= "Something went wrong";
					echo $msg;
					
					
				}
				
			}
				
		
			$setting_details="SELECT* FROM setting";
			$settings=mysqli_query($connect,$setting_details);												
			$setting=mysqli_fetch_array($settings,MYSQLI_BOTH);
			
			$system_name=$setting['system_name'];
			$system_title=$setting['system_title'];
			$establish_date=$setting['establish_date'];
			$district=$setting['district'];
			$city=$setting['city'];
			$phone=$setting['phone'];
			$email=$setting['email'];
			$address=$setting['address'];
			$currency=$setting['currency'];
			$language=$setting['language'];
			
			
			
		?>
		
		
		
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>
				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2>General Setting</h2></td></tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
						
							<tr>
								<td>Company Name</td>
								<td><input value="<?php echo $system_name;?>" required type="text" name="system_name" class="parent_info_input" id="system_name"></td>
							</tr>
							<tr>
								<td>Company Moto</td>
								<td><input value="<?php echo $system_title;?>" required type="text" name="system_title" class="parent_info_input" id="system_title"></td>
							</tr>
							<tr>
								<td>Phone</td>
								<td><input value="<?php echo $phone;?>" required type="text" name="phone" class="parent_info_input" id="phone"></td>
							</tr>
							<tr>
								<td>Address</td>
								<td><input value="<?php echo $address;?>" required type="text" name="address" class="parent_info_input" id="address"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input value="<?php echo $email;?>" required type="text" name="email" class="parent_info_input" id="email"></td>
							</tr>
							<tr>
								<td>Establishment Date</td>
								<td><input value="<?php echo $establish_date;?>" required type="date" name="establish_date" class="parent_info_input" id="email"></td>
							</tr>
							<tr>
								<td>District</td>
								<td><input value="<?php echo $district;?>" required type="text" name="district" class="parent_info_input" id="email"></td>
							</tr>
							<tr>
								<td>City</td>
								<td><input value="<?php echo $city;?>" required type="text" name="city" class="parent_info_input" id="email"></td>
							</tr>
							<tr>
								<td>Language</td>
								<td><input value="<?php echo $language;?>" required type="text" name="language" class="parent_info_input" id="language"></td>
							</tr>
							<tr>
								<td>Currency</td>
								<td><input value="<?php echo $currency;?>" required type="text" name="currency" class="parent_info_input" id="currency"></td>
							</tr>
							<tr>
								<td>Logo</td>
								<td><input value="<?php echo $academic_year;?>" required type="file" name="logo" class="parent_info_input" id="academic_year"></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" value="Update Information" name="parent_submit" class="parent_info_input" id="parent_submit"></td>
							</tr>
					</form>
						</table>				
				</div>
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

<?php
	
	
?>