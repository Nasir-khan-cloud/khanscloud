
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="style/style.css">
	
	

<style>
#sidebar{
	background-color:#fff;
	min-height: 1000px;
}
.dropbtn{
	
    
	color: black;
	font-family: arimo;
font-size: 12px;
	width:100%;
	height:40px;
    padding-left: 5px;
    font-size: 18px;
    cursor: pointer;
	text-align: left;
padding-left: 15px;
margin-left:10px;
border: none;
background: linear-gradient(#fff, #ddd);
}

.dropbtn:hover{
background: linear-gradient(#4c5d46, #ddd);
}




.dropdown{list-style:none;}
.dropdown-content {
    display: none;
    position: relative;
    z-index: 1;
	text-align: left;
	padding-top:10px;
	padding-bottom:10px;
}

.dropdown-content a {
    text-decoration: none;
    display: block;
	color: black;
	font-family: tahoma;
	font-size: 16px;
	margin-bottom:5px;
	margin-left: 15px;
	text-align: left;
	padding: 5px;
}
.dropdown-content a:hover{
color: blue;
background-color: #ddd;

}


.dropdown:hover .dropdown-content {
    display: block;
}

</style>
</head>
<body>
	<div id="sidebar" >
		
		<li class="dropdown">
		  <button class="dropbtn" onclick="parent.location='<?php echo "dashboard.php";?>'"><?php echo DASHBOARD_MENU;?></button>
		</li>

		<li class="dropdown">
		  <button class="dropbtn"><?php echo CLASS_MENU;?></button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/add_class.php'; ?>"><?php echo ADD_CLASS_MENU;?></a>
			<a href="<?php echo BASE_URL.'admin/manage_class.php'; ?>"><?php echo CLASS_INFORMATION_MENU;?></a>
			<a href="<?php echo BASE_URL.'admin/add_section.php'; ?>"><?php echo ADD_SECTION_MENU;?></a>
			<a href="<?php echo BASE_URL.'admin/manage_section.php'; ?>"><?php echo "Manage Branches";?></a>
		  </div>
		</li>
		

		<li class="dropdown">
		  <button class="dropbtn"><?php echo "Patients";?></button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/add_patient.php'; ?>"><?php echo "Manage Patient";?></a>
			<a href="<?php echo BASE_URL.'admin/patient_information.php'; ?>"><?php echo "Patient Information";?></a>
		  </div>
		</li>

		<li class="dropdown">
		  <button class="dropbtn"><?php echo "Doctors";?></button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/add_doctor.php'; ?>"><?php echo "Manage Doctor";?></a>
			<a href="<?php echo BASE_URL.'admin/doctor_information.php'; ?>"><?php echo "Doctor Information";?></a>
		  </div>
		</li>
		<li class="dropdown">
		  <button class="dropbtn">Patient's Bill</button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/create_patient_payment.php'; ?>">Create Patient Payment</a>
			<a href="<?php echo BASE_URL.'admin/patient_payment_status.php'; ?>">Patient Payment</a>
			<a href="<?php echo BASE_URL.'admin/payment_history_by_patient.php'; ?>">Payment History by Patient</a>
			<a href="<?php echo BASE_URL.'admin/patient_payment_report.php'; ?>">Patient Payment Report</a>
		  </div>
		</li>
		
		<li class="dropdown">
		  <button class="dropbtn">Expense</button>
		  <div class="dropdown-content">
				<a href="<?php echo BASE_URL.'admin/add-expense_category.php'; ?>">Add Expense Head</a>
			<a href="<?php echo BASE_URL.'admin/add-expense.php.php'; ?>">Add Expense</a>
			<a href="<?php echo BASE_URL.'admin/expense.php'; ?>">Expense Report</a>
		  </div>
		</li>
		
		
		<li class="dropdown">
		  <button class="dropbtn"><?php echo NOTICE_MENU;?></button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/add_noticeboard.php'; ?>"><?php echo MANAGE_NOTICE_MENU;?></a>
		  </div>
		</li>

		<li class="dropdown">
		  <button class="dropbtn"><?php echo SETTING_MENU;?></button>
		  <div class="dropdown-content">
			<a href="<?php echo BASE_URL.'admin/general_setting.php'; ?>"><?php echo GENERAL_SETTING_MENU;?></a>
			<a href="<?php echo BASE_URL.'admin/users.php'; ?>"><?php echo USER_SETTING_MENU;?></a>
			<a href="#"><?php echo MESSEGE_SETTING_MENU;?></a>
			<a href="#"><?php echo LANGUAGE_SETTING_MENU;?></a>
		  </div>
		</li>
	
	
	</div>
</body>
</html>
