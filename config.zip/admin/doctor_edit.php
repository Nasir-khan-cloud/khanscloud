
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		
		<?php
			$msg="";
			if(isset($_GET['doctor_id']))
			{
				$doctor_id=$_GET['doctor_id'];
				$doctor_details="SELECT* FROM doctor WHERE doctor_id='".$doctor_id."'";
				$details=mysqli_query($connect,$doctor_details);												
				$doctor=mysqli_fetch_array($details,MYSQLI_BOTH);
				
				$doctor_id=$doctor['doctor_id'];
				$name=$doctor['name'];
				$specialist=$doctor['specialist'];
				$birthday=$doctor['birthday'];
				$sex=$doctor['sex'];
				$blood_group=$doctor['blood_group'];
				$address=$doctor['address'];
				$phone=$doctor['phone'];
				$email=$doctor['email'];
				$password=$doctor['password'];	
				$photo=$doctor['photo'];
				
				
			}
			
			
			if(isset($_POST['doctor_submit']))
			{
				
				$doctor_name=$_POST['doctor_name'];
				$doctor_specialist=$_POST['doctor_specialist'];
				$doctor_birthday=$_POST['doctor_birthday'];
				$doctor_blood=$_POST['doctor_blood'];
				$doctor_address=$_POST['doctor_address'];
				$doctor_email=$_POST['doctor_email'];
				$doctor_phone=$_POST['doctor_phone'];
				$doctor_gender=$_POST['doctor_gender'];
				$salary=$_POST['salary'];
				$doctor_password=$_POST['doctor_password'];
				
				
			//Code for Updating Photo Image
				if(isset($_FILES['doctor_photo']['name'])){
					$unlink_photo=DIR_BASE.$photo;
					unlink($unlink_photo);
					
					$errors= array();
					$file_name = $_FILES['doctor_photo']['name'];
					$file_size =$_FILES['doctor_photo']['size'];
					$file_tmp =$_FILES['doctor_photo']['tmp_name'];
					$file_type=$_FILES['doctor_photo']['type'];
					$file_ext=strtolower(end(explode('.',$_FILES['doctor_photo']['name'])));


					if($file_size > 500000097152){
					$errors[]='File size must be excately 2 MB';
					}
					$new_logo_name="photo_".str_replace(" ","_",$doctor_name).$doctor_designation.".".$file_ext;
					if(empty($errors)==true){
					$photo_destination=DIR_doctor_IMAGE.$new_logo_name;

					if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
					$photo="image/doctor/".$new_logo_name;
					echo "photo uploaded";
					}else{
					print_r($errors);
					}
				}
				
				$doctor_update_query="UPDATE doctor SET name= '$doctor_name',designation= '$doctor_designation',birthday= '$doctor_birthday',sex= '$doctor_gender',blood_group= '$doctor_blood',address= '$doctor_address',phone= '$doctor_phone',email= '$doctor_email',password= '$doctor_password',staff_category='$department',photo='$photo',salary= '$salary' WHERE doctor_id='".$doctor_id."'";
				
				if(mysqli_query($connect, $doctor_update_query)){
					$msg= ENTRY_UPDATE_MSG;
					//header('location: doctor_information.php');
					//exit;
				}
				else
				{
					$msg= ENTRY_FAILED_MSG;
					
					
				}
				
			}
		
			
		?>
		
		
		
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>
				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2><?php echo STAFF_EDIT_TITLE;?></h2></td>
						<td><?php echo $msg;?></td>
						</tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
						
							<tr>
								<td><?php echo STAFF_NAME_FORM;?></td>
								<td><input value="<?php echo $name;?>" required type="text" name="doctor_name" class="doctor_info_input" id="doctor_name"></td>
							</tr>
							<tr>
								<td><?php echo DESIGNATION_FORM;?></td>
								<td><input value="<?php echo $specialist;?>" required type="text" name="doctor_specialist" class="doctor_info_input" id="doctor_designation"></td>
							</tr>
							<tr>
								<td><?php echo BIRTHDAY_FORM;?></td>
								<td><input value="<?php echo $birthday;?>" type="date" name="doctor_birthday" class="doctor_info_input" id="doctor_birthday"></td>
							</tr>
							
							<tr>
								<td><?php echo GENDER_FORM;?></td>
								<td>
									<select name="doctor_gender" class="doctor_info_input" id="doctor_gender">
										<option value="male"><?php echo MALE_FORM;?></option>
										<option value="female"><?php echo FEMALE_FORM;?></option>									
									</select>
								</td>
							</tr>
							<tr>
								<td><?php echo BLOOD_FORM;?></td>
								<td><input value="<?php echo $blood_group;?>" type="text" name="doctor_blood" class="doctor_info_input" id="doctor_blood"></td>
							</tr>
							<tr>
								<td><?php echo PHONE_FORM;?></td>
								<td><input value="<?php echo $phone;?>" required type="text" name="doctor_phone" class="doctor_info_input" id="doctor_phone"></td>
							</tr>
							<tr>
								<td><?php echo PRESENT_ADDRESS_FORM;?></td>
								<td><input value="<?php echo $address;?>" required type="text" name="doctor_address" class="doctor_info_input" id="doctor_address"></td>
							</tr>
							<tr>
								<td><?php echo EMAIL_FORM;?></td>
								<td><input value="<?php echo $email;?>" required type="text" name="doctor_email" class="doctor_info_input" id="doctor_email"></td>
							</tr>
							<tr>
								<td><?php echo PASSWORD_FORM;?></td>
								<td><input value="<?php echo $password;?>" required type="password" name="doctor_password" class="doctor_info_input" id="doctor_password"></td>
							</tr>
							<tr>
								<td><?php echo PHOTO_FORM;?></td>
								<td><input required type="file" name="doctor_photo" class="doctor_info_input" id="doctor_password"></td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" value="Update Information" name="doctor_submit" class="doctor_info_input" id="doctor_submit"></td>
							</tr>
					</form>
						</table>				
				</div>
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

<?php
	
	
?>