
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
			
			
				<?php 
					if(isset($_POST['submit_manual'])){
						$title=$_POST['manual_title'];
						$description=$_POST['manual_description'];
						$language=1;
						$insert_query="INSERT INTO user_manual(manual_title,manual_description,language) VALUES('$title','$description','$language')";
						mysqli_query($connect,$insert_query);
					}
				?>
					
				<table>
						<tr><form method="POST">
							<td>
								<input placeholder="Manual Title" style="width: 400px; height:50px;" name="manual_title"></textarea>
							</td>
						</tr>
						<tr>
							<td>
								<textarea placeholder="Manual Description" rows="15" cols="130" name="manual_description"></textarea>
							</td>
						</tr>
						<tr>
							<td>
								<input class="add_button" name="submit_manual" class="submit" type="submit" value="Add Manual"></td>
						
							</td>
						</form></tr>
					
				</table>
				<div style="margin-top: 20px;">
					
					<?php 
					$select_query="SELECT* FROM user_manual";
					$manuals=mysqli_query($connect,$select_query);
					foreach($manuals as $manual):
					
					?>
					<details style="margin: 0% 5% 0% 5%;">
					  <summary style="padding: 1%; background-color: #ddd; margin-bottom: 2px;"><div><h3><?php echo $manual['manual_title'];?></h3></div></summary>
					  <p><?php echo $manual['manual_description'];?></p>
					 
					</details>
						
						
					<?php endforeach;?>
				</div>

			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>