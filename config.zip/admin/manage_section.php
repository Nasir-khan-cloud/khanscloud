
	<style>
		.search_info_input{height: 35px;}
		#search{width: 80%;}
		#search_bar{width: 15%;}
		
	</style>
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
			
				<?php
					$duplicate=false;
					$search="";
					if(isset($_GET['bank_id'])){$bank_id=$_GET['bank_id'];
					}
					
					$section_info_query="SELECT* FROM section";
					if(isset($_GET['bank_id']))
					{
						$section_info_query="SELECT* FROM section WHERE bank_id='".$bank_id."'";
					}
					
					if(isset($_POST['search_submit']))
					{
						$search=$_POST['search'];
						$section_info_query="SELECT* FROM section WHERE manager_name LIKE '%$search%' or name LIKE '%$search%' OR manager_phone LIKE '%$search%' OR address LIKE '%$search%'";
					}
				?>
			
					<table style="margin-bottom:5px;"> 
						<tr>
							<td><h2><?php echo SECTION_INFORMATION_TITLE;?></h2></td>
						</tr>
						<tr style="background-color: #ddd;">
								<!--<td><?php echo CLASS_NAME_FORM;?></td> -->
								<td>	
									<select onchange="location=this.value;" type="button" class="search_info_input" data-toggle="dropdown">
										<option><?php echo "Select a Bank Name";?></option>
										<?php
										$class_name_query="SELECT* FROM class";
										$classes=mysqli_query($connect,$class_name_query);
										foreach($classes as $class): ?>
										<option <?php if($bank_id==$class['bank_id']){echo 'selected';}?>  value="<?php echo 'manage_section.php?bank_id='.$class['bank_id']?>"><?php echo $class['name']?></option>
										<?php endforeach;?>
									</select>
							
								</td>	
								<form method="POST">
									<td>
										<input placeholder="Search Branch Details" value="<?php echo $search;?>" type="text" name="search" style="float:left" class="search_info_input" id="search">
										<input  required type="submit" name="search_submit" class="search_info_input" value="Search" id="search_bar">
									</td>
								</form>				
							</tr>
					</table>
				
					<table class="table table-bordered datatable" id="table_export">
					
							<th class="table-header"><div><?php echo SERIAL_TABLE;?></div></th>
							<th class="table-header"><div><?php echo SECTION_NAME_FORM;?></div></th>
							<th class="table-header"><div><?php echo NUMERICAL_ID_FORM;?></div></th>
							<th class="table-header"><div><?php echo "Branch Address";?></div></th>
							<th class="table-header"><div><?php echo "Manager Name";?></div></th>
							<th class="table-header"><div><?php echo "Manager Phone";?></div></th>
							<th class="table-header"><div><?php echo "Manager Email";?></div></th>
							<th class="table-header"><div><?php echo TABLE_ACTION;?></div></th>
								
								
							<?php
							$sn=0;
							
							
							$sections=mysqli_query($connect,$section_info_query);
							foreach($sections as $section): ?>
										
								<tr>
									<td><?php  echo ++$sn;?></td>
									<td><?php echo $section['name'];?></td>
									<td><?php echo $section['numerical_name'];?></td>
									<td><?php echo $section['address'];?></td>
									<td><?php echo $section['manager_name'];?></td>
									<td><?php echo $section['manager_phone'];?></td>
									<td><?php echo $section['manager_email'];?></td>
									<td>
										
										<div class="btn-group">
											<select onchange="location=this.value;" type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
												<option>
													<a href="#"><?php echo TABLE_ACTION;?></a>
												</option>
												<!-- STUDENT EDITING LINK -->
												<option value="<?php echo 'section_edit.php?bank_id='.$section['bank_id'];?>"><?php echo EDIT_ACTION;?></option>
												
												<hr>
												<!-- STUDENT DELETION LINK -->
												<option value="<?php echo '?bank_id='.$bank_id.'&action=delete&student_id='.$student['student_id'];?>"><?php echo DELETE_ACTION;?></option>
												
											</Select>
										</div>
									</td>
								</tr>
							<?php endforeach;
						?>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
