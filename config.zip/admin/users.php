

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<?php 

			if(isset($_GET['admin_id']))
			{
				$success="";

				if(isset($_GET['action']))
				{

				$id=$_GET['admin_id'];

				$shop_delete_query = "DELETE FROM admin WHERE admin_id='".$id."'";
				if(mysqli_query($connect,$shop_delete_query)){
				echo "Admin=>".$id." has been Deleted";}
					else{ echo "Something went wrong";}
				}	
			}	
			?>
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr><td><h2>Admin Information</h2></td></tr>
						<tr>
							<td>
								<input class="add_button" type="button" onclick="parent.location='<?php echo "add_admin.php";?>'" value="Add an Admin"></td>
									
							</td>
						</tr>
					</table>
				
					<table class="table table-bordered datatable" id="table_export">
						<?php $success;?>
						<th class="table-header"><div>SN.</div></th>
						<th class="table-header"><div>Photo</div></th>
						<th class="table-header"><div>Name</div></th>
						<th class="table-header"><div>Email</div></th>
						<th class="table-header"><div>Username</div></th>
						<th class="table-header"><div>Password</div></th>
						<th class="table-header"><div>Level</div></th>
						<th class="table-header"><div>Options</div></th>
						
											
						<?php
						$sn=0;
						$admin_info_query="SELECT* FROM admin";
						$admins=mysqli_query($connect,$admin_info_query);
						foreach($admins as $admin): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>
								<td><img style="height:40px;width:40px;" src="<?php echo BASE_URL.$admin['photo'];?>" /></td>
								
								<td><?php echo $admin['name'];?></td>
								<td><?php echo $admin['email'];?></td>
								<td><?php echo $admin['username'];?></td>
								<td><?php echo $admin['password'];?></td>
								<td><?php echo $admin['level'];?></td>
								<td>
									
									<div class="btn-group">
										<select onchange="location=this.value;" type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
											Action
											<option>
												<a href="#">Action</a>
											</option>
											<!-- STUDENT EDITING LINK -->
											<option value="<?php echo 'admin_edit.php?admin_id='.$admin['admin_id'];?>">Edit</option>
											
											<hr>
											<!-- STUDENT DELETION LINK -->
											<option value="<?php echo '?action=delete&admin_id='.$admin['admin_id'];?>">Delete</option>
											
										</Select>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	
