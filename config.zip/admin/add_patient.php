
<?php
	$duplicate=false;
	if(isset($_GET['department_id'])){$department_id=$_GET['department_id'];}
	?>

<!DOCTYPE html>
<html>
	<head>	
	<style>	

		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>	
						<table class="insertion_table">
							<tr>
								<td>Department</td>
								<td>
									<select onchange="location=this.value;">
										<option value="<?php echo "?department_id=".""?>">Select a Department</option>
											<?php 
												$select_department_query="SELECT* FROM department";
												$result_departments=mysqli_query($connect,$select_department_query);
												while($department=mysqli_fetch_array($result_departments,MYSQLI_BOTH)){?>
												<option value="<?php echo "?department_id=".$department['department_id']?>"><?php echo $department['name'];?></option>
												
											
											<?php } ?>
									</select>
								</td>
							</tr>
							<tr>
								<td>Doctor</td>
								<td>
									<select onchange="location=this.value;">
										<option value="<?php echo "?doctor_id=".""?>">Select a Doctor</option>
											<?php 
												$select_doctor_query="SELECT* FROM doctor WHERE department_id='".$department_id."'";
												$result_doctors=mysqli_query($connect,$select_doctor_query);
												while($doctor=mysqli_fetch_array($result_doctors,MYSQLI_BOTH)){?>
												<option value="<?php echo "?department_id=".$department_id.'&doctor_id='.$doctor['doctor_id'];?>"><?php echo $doctor['name'];?></option>
												
											
											<?php } ?>
									</select>
								</td>
							</tr>
							
							<form method="POST"  enctype="multipart/form-data">
							
							<tr>
								<td>Name</td>
								<td><input required type="text" name="name" class="patient_info_input" id="patient_name"></td>
							</tr>
							<tr>
								<td>Father Name</td>
								<td><input required type="text" name="father" class="patient_info_input" id="patient_name"></td>
							</tr>
							<tr>
								<td>Mother Name</td>
								<td><input required type="text" name="mother" class="patient_info_input" id="patient_name"></td>
							</tr>
							<tr>
								<td>Registration Number</td>
								<td><input required type="text" name="reg_no" class="patient_info_input" id="patient_roll"></td>
							</tr>
							<tr>
								<td>Age</td>
								<td><input type="number" name="age" class="patient_info_input" id="patient_birthday"></td>
							</tr>
							
							<tr>
								<td>Gender</td>
								<td>
									<select name="patient_gender" class="patient_info_input" id="patient_gender">
										<option value="male">Male</option>
										<option value="female">Female</option>									
									</select>
								</td>
							</tr>
							<tr>
								<td>Blood</td>
								<td><input type="text" name="patient_blood" class="patient_info_input" id="patient_blood"></td>
							</tr>
							<tr>
								<td>Phone</td>
								<td><input required type="text" name="patient_phone" class="patient_info_input" id="patient_phone"></td>
							</tr>
							<tr>
								<td>Address</td>
								<td><input required type="text" name="patient_address" class="patient_info_input" id="patient_address"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input required type="text" name="patient_email" class="patient_info_input" id="patient_email"></td>
							</tr>
							<tr>
								<td>Password</td>
								<td><input required type="password" name="patient_password" class="patient_info_input" id="patient_password"></td>
							</tr>
							<tr>
								<td>Photo</td>
								<td><input  type="file" name="patient_photo" class="patient_info_input" id="patient_photo"></td>
							</tr>
							<tr>
								<td colspan="2"><input <?php if(!isset($_GET['doctor_id'])){echo 'disabled';}?>  type="submit" value="Add patient" name="patient_submit" class="patient_info_input" id="patient_submit"></td>
							</tr>
						
							
					</form>
						</table>
				
				
				</div>
			
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>




<?php
	if(isset($_GET['department_id'])){$department_id=$_GET['department_id'];}
	if(isset($_GET['doctor_id'])){$doctor_id=$_GET['doctor_id'];}
	
	if(isset($_POST['patient_submit']))
	{
		$patient_name=$_POST['name'];
		$reg_no=$_POST['reg_no'];
		$age=$_POST['age'];
		$father=$_POST['father'];
		$mother=$_POST['mother'];
		$patient_blood=$_POST['patient_blood'];
		$patient_address=$_POST['patient_address'];
		$patient_email=$_POST['patient_email'];
		$patient_phone=$_POST['patient_phone'];
		$patient_gender=$_POST['patient_gender'];
		$patient_password=$_POST['patient_password'];
		$addmission_date=date("Y/m/d");
		
		
		$patient_info_query="SELECT* FROM patient";
		$patients=mysqli_query($connect,$patient_info_query);
		foreach($patients as $patient):
			if(strcmp($patient_roll,$patient['roll'])==0 ){$duplicate=true; echo "Duplicate Roll Number";}	
			if(strcmp($patient_email,$patient['email'])==0 ){$duplicate=true; echo "Duplicate Email";}	
			if(strcmp($patient_phone,$patient['phone'])==0 ){$duplicate=true; echo "Duplicate Phone";}		
		endforeach;
		
		
		
		//Code for Uploading Image
		$errors= array();
      $file_name = $_FILES['patient_photo']['name'];
      $file_size =$_FILES['patient_photo']['size'];
      $file_tmp =$_FILES['patient_photo']['tmp_name'];
      $file_type=$_FILES['patient_photo']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['patient_photo']['name'])));
      
      /*$expensions= array("JPG","JPEG","PNG");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }*/
      
      if($file_size > 2000000097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $new_logo_name="photo_".str_replace(" ","_",$patient_name).$patient_roll.".".$file_ext;
      if(empty($errors)==true){
		 $photo_destination=DIR_patient_IMAGE.$new_logo_name;
		  
	  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
		 $patient_photo="image/patient/".$new_logo_name;
      }else{
         print_r($errors);
      }
		  $patient_submit_query="INSERT INTO patient(name,age,sex,blood_group,address,phone,email,father_name,mother_name,department_id,appointed_doctor_id,reg_id,photo,addmission_date,status)
		  VALUES('$patient_name','$age','$patient_gender','$patient_blood','$patient_address','$patient_phone','$patient_email','$father','$mother','$department_id','$doctor_id','$reg_no','$patient_photo','$addmission_date','1')";
		  
		if(mysqli_query($connect,$patient_submit_query)){
		$msg= ENTRY_SUCCESS_MSG;}
		else{
			$msg=ENTRY_FAILED_MSG;
		}
	  }
	
	


?>

	
	<script>
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




</script>