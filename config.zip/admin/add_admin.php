
<?php
	$duplicate=false;
	ob_start();
	?>

<!DOCTYPE html>
<html>
	<head>	
	<style>	

		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>
					<table style="margin-bottom:5px;">
						<tr><td><h2><?php echo "Insert an Admin";?></h2></td><td><?php echo $msg;?></td></tr>
					</table>				
					<table class="insertion_table">
							
					<form method="POST"  enctype="multipart/form-data">
						
						
							<tr>
								<td>Name</td>
								<td><input required type="text" name="admin_name" class="admin_info_input" id="admin_name"></td>
							</tr>
						
							<tr>
								<td>Email</td>
								<td><input required type="text" name="admin_email" class="admin_info_input" id="admin_email"></td>
							</tr>
							<tr>
								<td>Username</td>
								<td><input required type="text" name="admin_username" class="admin_info_input" id="admin_password"></td>
							</tr>
							<tr>
								<td>Password</td>
								<td><input required type="password" name="admin_password" class="admin_info_input" id="admin_password"></td>
							</tr>
							<tr>
								<td>Level</td>
								<td><input required type="text" name="admin_level" class="admin_info_input" id="admin_level"></td>
							</tr>
							<tr>
								<td>Photo</td>
								<td><input  type="file" name="admin_photo" class="admin_info_input" id="admin_photo"></td>
							</tr>
							<tr>
								<td colspan="2"><input   type="submit" value="Add admin" name="admin_submit" class="admin_info_input" id="admin_submit"></td>
							</tr>
						
							
					</form>
						</table>
				
				
				</div>
			
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>




<?php
	
	
	if(isset($_POST['admin_submit']))
	{
		$admin_name=$_POST['admin_name'];
		$admin_email=$_POST['admin_email'];
		$admin_username=$_POST['admin_username'];
		$admin_level=$_POST['admin_level'];
		$admin_password=$_POST['admin_password'];
		$created_date=date("Y/m/d");
		
		
		$admin_info_query="SELECT* FROM admin";
		$admins=mysqli_query($connect,$admin_info_query);
		foreach($admins as $admin):	
			if(strcmp($admin_email,$admin['email'])==0 ){$duplicate=true; echo "Duplicate Email";}		
		endforeach;
		
		
		
		//Code for Uploading Image
		$errors= array();
      $file_name = $_FILES['admin_photo']['name'];
      $file_size =$_FILES['admin_photo']['size'];
      $file_tmp =$_FILES['admin_photo']['tmp_name'];
      $file_type=$_FILES['admin_photo']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['admin_photo']['name'])));
      
      /*$expensions= array("JPG","JPEG","PNG");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }*/
      
      if($file_size > 2000000097152){
         $errors[]='File size must be excately 2 MB';
      }
	  $new_logo_name="photo_".str_replace(" ","_",$admin_email).".".$file_ext;
      if(empty($errors)==true){
		 $photo_destination=DIR_ADMIN_IMAGE.$new_logo_name;
		  
	  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
		 $admin_photo="image/admin/".$new_logo_name;
      }else{
         print_r($errors);
      }
	  
	  if($duplicate!=true)
	  {
		  $admin_submit_query="INSERT INTO admin(name,email,username,password,level,created_date,photo)
		  VALUES('$admin_name','$admin_email','$admin_username','$admin_password','$admin_level','$created_date','$admin_photo')";
		  
		mysqli_query($connect,$admin_submit_query);
		
		header('location: users.php');
		exit;
	  }
		
	}
	
	


?>




</script>