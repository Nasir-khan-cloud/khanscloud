
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		
		
			<?php
				if(isset($_GET['doctor_id']))
				{
					$doctor_id=$_GET['doctor_id'];
					$doctor_details="SELECT* FROM doctor WHERE doctor_id='".$doctor_id."'";
					$details=mysqli_query($connect,$doctor_details);												
					$doctor=mysqli_fetch_array($details,MYSQLI_BOTH);
					
					$doctor_id=$doctor['doctor_id'];
					$name=$doctor['name'];
					$specialist=$doctor['specialist'];
					$birthday=$doctor['birthday'];
					$sex=$doctor['sex'];
					$blood_group=$doctor['blood_group'];
					$address=$doctor['address'];
					$phone=$doctor['phone'];
					$email=$doctor['email'];
					$password=$doctor['password'];
					$join_date=$doctor['join_date'];
					$photo=$doctor['photo'];
					
					
				}
			?>
		
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">

				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2><?php echo "Details of Doctor";?> </h2></td>
						<td><?php echo STAFF_NAME_FORM." : ".$name;?></td></tr>
					</table>
					<div style="border-radius: 100%;"><img style="height:200px;width:200px;border:1px solid #ddd;border-radius: 100%;" src="<?php echo BASE_URL.$photo; ?>"><div>
					<table class="profile_table">
					
						<tr>
							<td><?php echo STAFF_NAME_FORM;?></td>
							<td><?php echo $name;?></td>
						</tr>
						<tr>
							<td><?php echo DESIGNATION_FORM;?></td>
							<td><?php echo $specialist;?></td>
						</tr>
					
						<tr>
							<td><?php echo EMAIL_FORM;?></td>
							<td><?php echo $email;?></td>
						</tr>
					
						<tr>
							<td><?php echo PHONE_FORM;?></td>
							<td><?php echo $phone;?></td>
						</tr>
					
						<tr>
							<td><?php echo PRESENT_ADDRESS_FORM;?></td>
							<td><?php echo $address;?></td>
						</tr>
					
						<tr>
							<td><?php echo BIRTHDAY_FORM;?></td>
							<td><?php echo $birthday;?></td>
						</tr>
					
						<tr>
							<td><?php echo BLOOD_FORM;?></td>
							<td><?php echo $blood_group;?></td>
						</tr>
						<tr>
							<td><?php echo GENDER_FORM;?></td>
							<td><?php echo $sex;?></td>
						</tr>
					
						<tr>
							<td><?php echo PASSWORD_FORM;?></td>
							<td><?php echo $password;?></td>
						</tr>
					
						<tr>
							<td><?php echo JOINING_DATE_FORM;?></td>
							<td><?php echo $join_date;?></td>
						</tr>
					
						<tr>
							<td colspan="2">
							<input type="button" onclick="parent.location='<?php echo "doctor_information.php";?>'" value="Back"></td>
						</tr>
						
					</table>
				
				
				
				
				
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>