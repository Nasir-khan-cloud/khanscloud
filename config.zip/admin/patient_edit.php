
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		
		<?php
				if(isset($_GET['student_id']))
				{
					$student_id=$_GET['student_id'];
					$student_details="SELECT* FROM student WHERE student_id='".$student_id."'";
					$details=mysqli_query($connect,$student_details);												
					$student=mysqli_fetch_array($details,MYSQLI_BOTH);
					
					$student_id=$student['student_id'];
					$name=$student['name'];
					$birthday=$student['birthday'];
					$sex=$student['sex'];
					$blood_group=$student['blood_group'];
					$address=$student['address'];
					$phone=$student['phone'];
					$phone=$student['father_name'];
					$phone=$student['mother_name'];
					$email=$student['email'];
					$password=$student['password'];			
					$class_name_query="SELECT name FROM class WHERE class_id='".$student['class_id']."'";
					$details=mysqli_query($connect,$class_name_query);												
					$class=mysqli_fetch_array($details,MYSQLI_BOTH);
					$class=$class['name'];
						
					$section_name_query="SELECT name FROM section WHERE section_id='".$student['section_id']."'";
					$details=mysqli_query($connect,$section_name_query);												
					$section=mysqli_fetch_array($details,MYSQLI_BOTH);
					$section=$section['name'];
					
					$parent_name_query="SELECT name FROM parent WHERE parent_id='".$student['parent_id']."'";
					$details=mysqli_query($connect,$parent_name_query);												
					$parent=mysqli_fetch_array($details,MYSQLI_BOTH);
					$parent=$parent['name'];
					
					
					$roll=$student['roll'];
					$photo=$student['photo'];
					
					$transport_name_query="SELECT route_name FROM transport WHERE transport_id='".$student['transport_id']."'";
					$details=mysqli_query($connect,$transport_name_query);												
					$transport=mysqli_fetch_array($details,MYSQLI_BOTH);
					$transport=$transport['route_name'];
					
					$dormitory_name_query="SELECT name FROM dormitory WHERE dormitory_id='".$student['dormitory_id']."'";
					$details=mysqli_query($connect,$dormitory_name_query);												
					$dormitory=mysqli_fetch_array($details,MYSQLI_BOTH);
					$dormitory=$dormitory['name'];
					
					
				}
			?>
		
		
		
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div>
				<div>	
					<table style="margin-bottom:5px;">
						<tr><td><h2>Student Information Update</h2></td></tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
							<tr>
								<td>Section</td>
								<td>
									<select  type="text" name="student_section" class="student_info_input" id="student_section">
										<?php
										$section_query="SELECT* FROM section WHERE class_id='".$student['class_id']."'";
										$sections=mysqli_query($connect,$section_query);
										foreach($sections as $section): ?>
										<option  value="<?php echo $section['section_id']?>"><?php echo $section['name']?></option>
										<?php endforeach;?>
									
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Parent</td>
								<td>
									<select type="text" name="student_parent" class="student_info_input" id="student_parent">
										<?php
										$parent_query="SELECT* FROM parent";
										$parents=mysqli_query($connect,$parent_query);
										foreach($parents as $parent): ?>
										<option value="<?php echo $parent['parent_id']?>"><?php echo $parent['name']?></option>
										<?php endforeach;?>
									
									</select>
								</td>
							</tr>
						
						
							<tr>
								<td>Name</td>
								<td><input value="<?php echo $name;?>" required type="text" name="student_name" class="student_info_input" id="student_name"></td>
							</tr>
							<tr>
								<td>Roll</td>
								<td><input value="<?php echo $roll;?>" required type="text" name="student_roll" class="student_info_input" id="student_roll"></td>
							</tr>
							<tr>
								<td>Birthday</td>
								<td><input type="date" name="student_birthday" class="student_info_input" id="student_birthday"></td>
							</tr>
							
							<tr>
								<td>Gender</td>
								<td>
									<select name="student_gender" class="student_info_input" id="student_gender">
										<option value="male">Male</option>
										<option value="female">Female</option>									
									</select>
								</td>
							</tr>
							<tr>
								<td>Blood</td>
								<td><input value="<?php echo $blood_group;?>" type="text" name="student_blood" class="student_info_input" id="student_blood"></td>
							</tr>
							<tr>
								<td>Phone</td>
								<td><input value="<?php echo $phone;?>" required type="text" name="student_phone" class="student_info_input" id="student_phone"></td>
							</tr>
							<tr>
								<td>Father Name</td>
								<td><input value="<?php echo $father;?>" required type="text" name="student_father" class="student_info_input" id="student_father"></td>
							</tr>
							<tr>
								<td>Mother Name</td>
								<td><input value="<?php echo $mother;?>" required type="text" name="student_mother" class="student_info_input" id="student_mother"></td>
							</tr>
							<tr>
								<td>Address</td>
								<td><input value="<?php echo $address;?>" required type="text" name="student_address" class="student_info_input" id="student_address"></td>
							</tr>
							<tr>
								<td>Email</td>
								<td><input value="<?php echo $email;?>" required type="text" name="student_email" class="student_info_input" id="student_email"></td>
							</tr>
							<tr>
								<td>Password</td>
								<td><input value="<?php echo $password;?>" required type="password" name="student_password" class="student_info_input" id="student_password"></td>
							</tr>
							
							<tr>
								<td>Dormitory</td>
								<td>
									<select type="text" name="student_dormitory" class="student_info_input" id="student_dormitory">
										<?php
										$dormitory_query="SELECT* FROM dormitory";
										$dormitories=mysqli_query($connect,$dormitory_query);
										foreach($dormitories as $dormitory): ?>
										<option value="<?php echo $dormitory['dormitory_id']?>"><?php echo $dormitory['name']?></option>
										<?php endforeach;?>
									
									</select>
								</td>
							</tr>
							
							<tr>
								<td>Transport Route</td>
								<td>
									<select type="text" name="student_transport" class="student_info_input" id="student_transport">
										<?php
										$transport_query="SELECT* FROM transport";
										$transports=mysqli_query($connect,$transport_query);
										foreach($transports as $transport): ?>
										<option value="<?php echo $transport['transport_id']?>"><?php echo $transport['route_name']?></option>
										<?php endforeach;?>
									
									</select>
								</td>
							</tr>
							<tr>
								<td colspan="2"><input type="submit" value="Update Information" name="student_submit" class="student_info_input" id="student_submit"></td>
							</tr>
					</form>
						</table>				
				</div>
					
				</div>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>

<?php
	
	if(isset($_POST['student_submit']))
	{
		$student_section=$_POST['student_section'];
		$student_parent=$_POST['student_parent'];
		$student_name=$_POST['student_name'];
		$student_roll=$_POST['student_roll'];
		$student_birthday=$_POST['student_birthday'];
		$student_blood=$_POST['student_blood'];
		$student_address=$_POST['student_address'];
		$student_email=$_POST['student_email'];
		$student_phone=$_POST['student_phone'];
		$student_father=$_POST['student_father'];
		$student_mother=$_POST['student_mother'];
		$student_gender=$_POST['student_gender'];
		$student_password=$_POST['student_password'];
		$student_dormitory=$_POST['student_dormitory'];
		$student_transport=$_POST['student_transport'];
		
		$student_update_query="UPDATE student SET name= '$student_name',birthday= '$student_birthday',sex= '$student_gender',blood_group= '$student_blood',address= '$student_address',phone= '$student_phone',email= '$student_email',password= '$student_password',father_name= '$student_father',mother_name= '$student_mother',
section_id= '$student_section',parent_id= '$student_parent',roll= '$student_roll',transport_id= '$student_transport',dormitory_id= '$student_dormitory' WHERE student_id='".$student_id."'";
		
		if(mysqli_query($connect, $student_update_query)){
			$msg= "Records were updated successfully.";
			echo $msg;
			header('location: shop-status.php');
			exit;
		}
		else
		{
			$msg= "Something went wrong";
			echo $msg;
			
			
		}
		
	}
?>