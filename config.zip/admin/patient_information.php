

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<div class="select_class">
				<button onclick="select_class_dropdown_function()" class="select_dropdown_button">Select Class</button>
				  <div id="myDropdown" class="dropdown-elements">
				  
						<?php 
							$select_class_query="SELECT* FROM class";
							$result_classes=mysqli_query($connect,$select_class_query);
							while($classes=mysqli_fetch_array($result_classes,MYSQLI_BOTH)){?>
							<a href="<?php echo "?class_id=".$classes['class_id']?>"><?php echo $classes['name'];?></a>
						
						
						<?php } ?>
				  </div>
				</div>
				
				
				
				
				<?php 
				
				if(isset($_GET['class_id']))
				{
					$success="";
					$class_id=$_GET['class_id'];

					if(isset($_GET['action']))
					{

					$id=$_GET['student_id'];

					$shop_delete_query = "DELETE FROM student WHERE student_id='".$id."'";
					if(mysqli_query($connect,$shop_delete_query)){
					echo "Student=>".$id." has been Deleted";}
						else{ echo "Something went wrong";}
					}				
				?>
				
					<table class="table table-bordered datatable" id="table_export">
						<?php $success;?>
						<th class="table-header"><div>Roll Number</div></th>
						<th class="table-header"><div>Photo</div></th>
						<th class="table-header"><div>Name</div></th>
						<th class="table-header"><div>Address</div></th>
						<th class="table-header"><div>Email</div></th>
						<th class="table-header"><div>Phone</div></th>
						<th class="table-header"><div>Options</div></th>
						
											
						<?php $sn=0;
						$student_info_query="SELECT* FROM student WHERE class_id='".$class_id."'";
						$students=mysqli_query($connect,$student_info_query);
						foreach($students as $student): ?>
                                    
							<tr class="<?php $sn++; if($sn%2==0){echo "table-row-even";}else{echo "table-row-odd";}?>">
								<td><?php echo $student['roll'];?></td>
								<td><img style="height:40px;width:40px;" src="<?php echo BASE_URL.$student['photo'];?>" /></td>
								<td><?php echo $student['name'];?></td>
								<td><?php echo $student['address'];?></td>
								<td><?php echo $student['email'];?></td>
								<td><?php echo $student['phone'];?></td>
								<td>
									
									<div class="btn-group">
										<select id="select" onchange="location=this.value;" class="btn btn-default btn-sm dropdown-toggle" >
											Action
											<!-- STUDENT MARKSHEET LINK  -->
											<option>
												<a href="#">Action</a>
											</option>
											<option value="<?php echo 'student_marksheet.php?student_id='.$student['student_id'].'&class_id='.$class_id;?>">Marksheet</option>
											
											<!-- STUDENT PROFILE LINK -->
											<option value="<?php echo 'student_profile.php?student_id='.$student['student_id'];?>">Profile</option>
											
											<!-- STUDENT EDITING LINK -->
											<option value="<?php echo 'student_edit.php?student_id='.$student['student_id'];?>">Edit</option>
											
											<hr>
											<!-- STUDENT DELETION LINK -->
											<option action="delete"  value="<?php echo '?class_id='.$class_id.'&action=delete&student_id='.$student['student_id'];?>">Delete</option>
											
										</Select>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
					</table>					
				 <?php }?>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

	<script type="text/javascript">
	
	
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>