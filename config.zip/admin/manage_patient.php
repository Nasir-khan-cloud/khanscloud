
<?php
	$duplicate=false;
	?>

<!DOCTYPE html>
<html>
	<head>	
	<style>	

		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
			
			<?php
				if(isset($_POST['teacher_submit']))
				{
					$teacher_name=$_POST['teacher_name'];
					$teacher_designation=$_POST['teacher_designation'];
					$teacher_education=$_POST['teacher_education'];
					$teacher_birthday=$_POST['teacher_birthday'];
					$teacher_blood=$_POST['teacher_blood'];
					$teacher_address=$_POST['teacher_address'];
					$teacher_email=$_POST['teacher_email'];
					$teacher_phone=$_POST['teacher_phone'];
					$teacher_gender=$_POST['teacher_gender'];
					$teacher_password=$_POST['teacher_password'];
					$teacher_salary=$_POST['teacher_salary'];
					$teacher_dept=$_POST['department_id'];
					$teacher_username=$_POST['teacher_username'];
					$joining_date=$_POST['joining_date'];
					
					
					$teacher_info_query="SELECT* FROM teacher";
					$teachers=mysqli_query($connect,$teacher_info_query);
					foreach($teachers as $teacher):	
						if(strcmp($teacher_email,$teacher['email'])==0 ){$duplicate=true; echo "Duplicate Email";}	
						if(strcmp($teacher_phone,$teacher['phone'])==0 ){$duplicate=true; echo "Duplicate Phone";}		
					endforeach;
					
					
					
					//Code for Uploading Image
					$errors= array();
				  $file_name = $_FILES['teacher_photo']['name'];
				  $file_size =$_FILES['teacher_photo']['size'];
				  $file_tmp =$_FILES['teacher_photo']['tmp_name'];
				  $file_type=$_FILES['teacher_photo']['type'];
				  $file_ext=strtolower(end(explode('.',$_FILES['teacher_photo']['name'])));
				  
				  /*$expensions= array("JPG","JPEG","PNG");
				  
				  if(in_array($file_ext,$expensions)=== false){
					 $errors[]="extension not allowed, please choose a JPEG or PNG file.";
				  }*/
				  
				  if($file_size > 2000000097152){
					 $errors[]='File size must be excately 2 MB';
				  }
				  $new_logo_name="photo_".str_replace(" ","_",$teacher_name).$teacher_designation.".".$file_ext;
				  if(empty($errors)==true){
					 $photo_destination=DIR_TEACHER_IMAGE.$new_logo_name;
					  
				  if(move_uploaded_file($file_tmp,$photo_destination)){$success="Uploaded Successfully!";}
					 $teacher_photo="image/teacher/".$new_logo_name;
				  }else{
					 print_r($errors);
				  }
				  
				  if($duplicate!=true)
				  {
					  $teacher_submit_query="INSERT INTO teacher(name,education,birthday,sex,blood_group,address,phone,email,password,designation,join_date,photo)
					  VALUES('$teacher_name','$teacher_education','$teacher_birthday','$teacher_gender','$teacher_blood','$teacher_address','$teacher_phone','$teacher_email','$teacher_password','$teacher_designation','$joining_date','$teacher_photo')";
					  
					if(mysqli_query($connect,$teacher_submit_query))
						
					{
						$msg="Staff Successfully Inserted";
						header('location: teacher_information.php');
						exit;
					}
					else{
						$msg=ENTRY_FAILED_MSG;
					}
					
				  }
				  else{
					  $msg=ENTRY_DUPLICATE_MSG;
				  }
				}
			?>
			
			
			
				<div>	
					<table>
						<tr><td><h2><?php echo ADD_STAFF_TITLE;?></h2></td></tr>
						<tr><td><h4><?php echo $msg;?></h4></td></tr>
					</table>
					<table class="insertion_table">
							
					<form method="POST"  enctype="multipart/form-data">
						
						
							<tr>
								<td><?php echo "Name";?></td>
								<td><input required type="text" name="name" class="info_input" id="teacher_name"></td>
							</tr>
							<tr>
								<td><?php echo "Age";?></td>
								<td><input required type="number" name="age" class="info_input" id="teacher_name"></td>
							</tr>
							<tr>
								<td><?php echo "Address";?></td>
								<td><input type="text" name="address" class="info_input" id="teacher_birthday"></td>
							</tr>
							
							<tr>
								<td><?php echo GENDER_FORM;?></td>
								<td>
									<select name="gender" class="info_input" id="teacher_gender">
										<option value="male"><?php echo MALE_FORM;?></option>
										<option value="female"><?php echo FEMALE_FORM;?></option>									
									</select>
								</td>
							</tr>
							<tr>
								<td><?php echo BLOOD_FORM;?></td>
								<td><input type="text" name="teacher_blood" class="info_input" id="teacher_blood"></td>
							</tr>
							<tr>
								<td><?php echo PHONE_FORM;?></td>
								<td><input required type="text" name="teacher_phone" class="info_input" id="teacher_phone"></td>
							</tr>
							<tr>
								<td><?php echo PHOTO_FORM;?></td>
								<td><input  type="file" name="teacher_photo" class="info_input" id="teacher_photo"></td>
							</tr>
							<tr>
								<td colspan="2"><input   type="submit" value="Add Patient" name="submit" class="info_input" id="teacher_submit"></td>
							</tr>
						
							
					</form>
						</table>
				
				
				</div>
			
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>


