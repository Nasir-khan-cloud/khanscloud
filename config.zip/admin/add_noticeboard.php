<?php ob_start();?>

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php $msg=""; 
				if(isset($_GET['action'])&& isset($_GET['id'])){
					$action=$_GET['action'];
					$id=$_GET['id'];
					$delete_query="DELETE FROM noticeboard WHERE notice_id='".$id."'";
					
					if(mysqli_query($connect, $delete_query)){
						$msg= "Notice were Deleted successfully.";
					}
					else
					{
						$msg= "Could not delete.";
						
						
					}
				}
				
				if(isset($_POST['notice_submit']))
				{
					$title=$_POST['title'];
					$description=$_POST['description'];
					$date=date("y/m/d");
					$notice_query="INSERT INTO noticeboard(notice_title,notice,created_date)
					VALUES('$title','$description','$date')";
					if(mysqli_query($connect, $notice_query)){
						$msg= "Notice were Added successfully.";
					}
					else
					{
						$msg= "Something went wrong";
						
						
					}
				}
			?>
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Add Noticeboard</h2>
							</td>
						</tr>
					
							<tr><td><?php echo $msg;?></td></tr>
					</table>
					<table style="margin-bottom:5px;">
					
						<form method="POST">
						<tr>
							<td>Notice Title : </td>
							<td><input type="text" name="title"></td>
						</tr>
						<tr>
							<td>Notice Description : </td>
							<td><textarea cols="75" rows="8" name="description"></textarea></td>
						</tr>
						<tr>
							<td colspan="2"><input type="submit" name="notice_submit" value="Submit Notice"></td>
						</tr>
						</form>
					</table>
					
					<table style="margin-bottom:5px;" class="select_bar" id="bar">
					
						<th class="table-header">SN.</th>
						<th class="table-header">Notice_title</th>
						<th class="table-header">Notice</th>
						<th class="table-header">Action</th>				
						<?php
						$sn=0;
						$notice_query="SELECT* FROM noticeboard";
						$notices=mysqli_query($connect,$notice_query);
						foreach($notices as $notice): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>					
								
								<td><?php echo $notice['notice_title'];?></td>
								<td><?php echo $notice['notice'];?></td>
								<td>
									
									<div class="btn-group">
										<a href="<?php echo ADMIN_URL."add_noticeboard.php?action=delete&id=".$notice['notice_id'];?>" onclick="return confirm('Are you sure??');">Delete</a>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
					</table>
					<table>
						<tr>
							<td colspan="2">
								<input class="add_button" type="button" onclick="parent.location='<?php echo "dashboard.php";?>'" value="Back to Dashboard"></td>
							
							</td>
						</tr>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

			
	<script>
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




</script>
