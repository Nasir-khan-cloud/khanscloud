
<!DOCTYPE html>
<html>
	<head>	<style>	
		<link rel="stylesheet" href="style.css"  type="text/css" media="all"></style>
	</head>
	
	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
				<table>
					<tr>
						<td cols="3"><h2>Get in Touch.....</h2></td>
					</tr>
				</table>
				<table>
					<tr>
						<th><h3> <u><b>Billing & Sales Section</b></u></h3></th>
						<th> <h3> <u><b>Corporate Section</b></u></h3></th>
						<th> <h3> <u><b>Support Section</b></u></h3></th>
					</tr>
					<tr>
						<th> <em>sales@softntechnology.com</em></th>
						<th>  <em>admin@softntechnology.com</em></th>
						<th>  <em>support@softntechnology.com</em></th>
					</tr>
					<tr>
						<th> 01734544545</th>
						<th> 01712034484</th>
						<th> 01756560928</th>
					</tr>
					<tr>
						<th> Billing & Sales Section</th>
						<th> Corporate Section</th>
						<th> Support Section</th>
					</tr>
					<tr>
						<th> </th>
						<th> </th>
						<th> </th>
					</tr>
				</table>
			</div>
		</div>
			
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
</html>