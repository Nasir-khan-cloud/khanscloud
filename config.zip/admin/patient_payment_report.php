

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php			
			$msg="";
				
				$from_date=date("y/m/d");
				$to_date=date("y/m/d");
				
				if(isset($_POST['submit_report']))
				{
					
					$from_date=$_POST['from_date'];
					$to_date=$_POST['to_date'];
					
				}
			
			?>
			
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Payment Report by Date</h2>
							</td>
						</tr>
						<tr><td><h2><? echo $msg;?></h2></td></tr>
						<form method="POST">
							<tr>
							
								<td>From 
									<input type="date" name="from_date" value="<?php echo $from_date;?>" >
								</td>
								<td>To
									<input type="date" name="to_date" value="<?php echo $to_date;?>">
								</td>
								<td>
									<input class="add_button" type="submit" name="submit_report">
								</td>
							</tr>
						</form>
					</table>
					
					
					
					<?php
					if(isset($_POST['submit_report']))
					{ ?>
					<table class="select_bar" id="bar">
						<form method="POST">
							<th class="table-header">Student Name</th>
							<th class="table-header">Payment Name</th>
							<th class="table-header">Payment Amount</th>
							<th class="table-header">Paid Amount</th>
							<th class="table-header">Due Amount</th>
							<th class="table-header">Paid Date</th>
							<th class="table-header">Comment</th>
						<?php
							$total_amount=0;
							$total_paid=0;
							$total_due=0;
							$payment_query="SELECT ppd.*,pph.name as payment_head FROM patient_payment_details ppd INNER JOIN patient_payment_head pph ON(pph.payment_id=ppd.payment_head_id)  WHERE payment_date>='".$from_date."' AND payment_date<='".$to_date."'AND status=1 ORDER BY payment_date DESC";
							
							$payments=mysqli_query($connect,$payment_query);
							foreach($payments as $payment):
						?>
							<tr>
								<td>
									<?php
									echo "--(".$payment['patient_id'].")";
									?>
								</td>
								<td>
									<?php
									echo $payment['payment_head'];
									
									?>
								</td>
								<td>
									<?php $total_amount+=$payment['amount']; echo $payment['amount'];?>
								</td>
								<td>
									<?php $total_paid+=$payment['paid'];  echo $payment['paid'];?>
								</td>
								<td>
									<?php  echo $due=$payment['amount']-$payment['paid'];$total_due+=$due;?>
								</td>
								<td>
									<?php  echo $payment['payment_date'];?>
								</td>
								<td>
									<?php  echo $payment['remark']; ?>;
								</td>
							</tr>
							<?php endforeach; ?>
							<tr>
								<td colspan="2"></td>
								<td><h3>Total</h3></td>
								<td><h3><?php echo "Amount : ".$total_amount;?></h3></td>
								<td><h3><?php echo "Paid : ".$total_paid;?></h3></td>
								<td><h3><?php echo "Due : ".$total_due;?></h3></td>
								
								<td></td>
								<td></td>
							</tr>
						</form>
						<tr></tr>
					</table>
						<?php }?>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

			
