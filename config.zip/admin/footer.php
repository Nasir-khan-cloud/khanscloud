
<html><body>
<hr>
<footer id="footer"> <a href="#">A Project, Developed by Group C .</a>Copyright &copy; 2017 . All Right Received.</footer></div>
</body></html>
