

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
		
			<div id="d-wrapper">
			<?php 
					if(isset($_GET['action']) && isset($_GET['department_id']))
					{
						$department_id=$_GET['department_id'];
						$subject_id=$_GET['department_id'];
						$delete_query="DELETE FROM department WHERE department_id='".$department_id."'";
						if(mysqli_query($connect,$delete_query))
						{
							$msg=ENTRY_DELETE_MSG;
						}
						else
						{
							$msg=ENTRY_FAILED_MSG;
						}
					}
					
					if(isset($_POST['department_submit']))
				{
					$department_name=$_POST['department_name'];
					$department_numeric=$_POST['department_numeric'];
					
					
					$department_info_query="SELECT* FROM department";
					$departments=mysqli_query($connect,$department_info_query);
					foreach($departments as $department):	
						if(strcmp($department_name,$department['name'])==0 ){$duplicate=true; echo "Duplicate Name";}	
						if(strcmp($department_numeric,$class['numerical_name'])==0 ){$duplicate=true; echo "Duplicate Code";}		
					endforeach;
				  if($duplicate!=true)
				  {
					  $department_submit_query="INSERT INTO department(name,numerical_name)VALUES('$department_name','$department_numeric')";
					  
					if(mysqli_query($connect,$department_submit_query)){
						$msg= ENTRY_SUCCESS_MSG;
						//header('location: manage_class.php');
						//exit;
					}
					else{
						$msg=ENTRY_FAILED_MSG;
					}
				  }
				  else{
					  $msg=ENTRY_DUPLICATE_MSG;
				  }
					
				}
			?>
					
					<table style="margin-bottom:5px;">
						<tr>
							<td><h2><?php echo "Department Information";?></h2></td>
							<td><?php echo $msg;?></td>
						</tr>
					</table>
					
					<table>
					<form method="POST"  enctype="multipart/form-data">
						
						
							<tr>
								<td><?php echo "Department Name";?></td>
								<td><?php echo "Numerical Symbol";?></td>
								<td></td>
								
							</tr>
						
							<tr>
							<td><input required type="text" name="department_name" class="department_info_input" id="department_name"></td>
								<td><input required type="text" name="department_numeric" class="department_info_input" id="department_numeric"></td>
							
								<td colspan="2"><input class="add_button"  type="submit" value="Add Department" name="department_submit" class="department_info_input" id="department_submit"></td>
							
							</tr>
						
							
					</form>
						</table>
				
					<table class="table table-bordered datatable" id="table_export">
						
						<?php $success;?>
						<th class="table-header"><div><?php echo SERIAL_TABLE;?></div></th>
						<th class="table-header"><div><?php echo "Department Name";?></div></th>
						<th class="table-header"><div><?php echo "Numerical Symbol";?></div></th>
						<th class="table-header"><div><?php echo TABLE_ACTION;?></div></th>
						
											
						<?php
						$sn=0;
						$department_info_query="SELECT* FROM department";
						$departments=mysqli_query($connect,$department_info_query);
						foreach($departments as $department): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>
								<td><?php echo $department['name'];?></td>
								<td><?php echo $department['numerical_name'];?></td>
								<td>
									
									<div class="btn-group">
										<select onchange="location=this.value;" type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
										
											<option>
												<a href="#"><?php echo TABLE_ACTION;?></a>
											<hr>
											<!-- STUDENT DELETION LINK -->
											<option value="<?php echo '?action=delete&department_id='.$department['department_id'];?>"><?php echo DELETE_ACTION;?></option>
											
										</Select>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	
