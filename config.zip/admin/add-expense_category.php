

	<body>
		
		<div id="d-header"><?php require_once 'header.php'; ?></div>
		<div id="d-container">
			<div class="d-sidebar"><?php require_once 'navigation.php'; ?></div>
			
			<?php $msg=""; 
				if(isset($_GET['action'])&& isset($_GET['id'])){
					$action=$_GET['action'];
					$id=$_GET['id'];
					$delete_query="DELETE FROM expense_category WHERE expense_category_id='".$id."'";
					
					if(mysqli_query($connect, $delete_query)){
						$msg= "Records were Deleted successfully.";
					}
					else
					{
						$msg= "Something went wrong";
						
						
					}
				}
				
				if(isset($_POST['expense_cat_submit']))
				{
					$cat_name=$_POST['expense_cat_name'];
					$cat_query="INSERT INTO expense_category(name) VALUES('$cat_name')";
					if(mysqli_query($connect, $cat_query)){
						$msg= "Records were Added successfully.";
					}
					else
					{
						$msg= "Something went wrong";
						
						
					}
				}
			?>
			
			
			
		
			<div id="d-wrapper">
					<table style="margin-bottom:5px;">
						<tr>
							<td>
								<h2>Expense Record</h2>
							</td>
						</tr>
					
							<tr><td><?php echo $msg;?></td></tr>
					</table>
					<table style="margin-bottom:5px;">
						<tr>
							<form method="POST">
								<td>Category Name : </td>
								<td><input type="text" name="expense_cat_name"></td>
								<td><input type="submit" name="expense_cat_submit" value="Create Category"></td>
							</form>
						</tr>
					</table>
					
					<table style="margin-bottom:5px;" class="select_bar" id="bar">
					
						<th class="table-header">SN.</th>
						<th class="table-header">Category_ID</th>
						<th class="table-header">expense Category</th>
						<th class="table-header">Action</th>				
						<?php
						$sn=0;
						$expense_cat_query="SELECT* FROM expense_category";
						$expense_categories=mysqli_query($connect,$expense_cat_query);
						foreach($expense_categories as $expense_category): ?>
                                    
							<tr>
								<td><?php  echo ++$sn;?></td>					
								
								<td><?php echo $expense_category['expense_category_id'];?></td>
								<td><?php echo $expense_category['name'];?></td>
								<td>
									
									<div class="btn-group">
										<a href="<?php echo ADMIN_URL."add-expense_category.php?action=delete&id=".$expense_category['expense_category_id'];?>" onclick="return confirm('Are you sure??');">Delete</a>
									</div>
								</td>
							</tr>
						<?php endforeach;?>
					</table>
					<table>
						<tr>
							<td colspan="2">
								<input class="add_button" type="button" onclick="parent.location='<?php echo "expense.php";?>'" value="Back to expense"></td>
							
							</td>
						</tr>
					</table>
			</div>
		</div>
		<div id="clear"></div>
		<div id="d-footer"><?php require_once 'footer.php'; ?></div>
	</body>
	

			
	<script>
	function select_class_dropdown_function() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.select_dropdown_button')) {

    var select_class = document.getElementsByClassName("dropdown-elements");
    var i;
    for (i = 0; i < select_class.length; i++) {
      var openDropdown = select_class[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}




</script>
